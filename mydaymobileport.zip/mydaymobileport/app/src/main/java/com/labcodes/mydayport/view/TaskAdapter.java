package com.labcodes.mydayport.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter; // Using ListAdapter for better updates
import androidx.recyclerview.widget.RecyclerView;

import com.labcodes.mydayport.R; // For accessing layout and view IDs
import com.labcodes.mydayport.model.Task; // Your Task model
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class TaskAdapter extends ListAdapter<Task, TaskAdapter.TaskViewHolder> {

    private final OnTaskClickListener taskClickListener;
    private final OnTaskOptionsClickListener optionsClickListener;
    private final OnTaskCheckboxClickListener checkboxClickListener;

    private List<String> selectedTaskIdsForBulkAction = new ArrayList<>(); // Store list of selected cb

    public interface OnTaskClickListener { void onTaskClick(Task task); }
    public interface OnTaskOptionsClickListener { void onTaskOptionsClick(Task task, View anchorView); }
    public interface OnTaskCheckboxClickListener { void onTaskSelectionChanged(Task task, boolean isSelectedForBulkAction); }

    public TaskAdapter(OnTaskClickListener taskClickListener,
                       OnTaskOptionsClickListener optionsClickListener,
                       OnTaskCheckboxClickListener checkboxClickListener) {
        super(DIFF_CALLBACK);
        this.taskClickListener = taskClickListener;
        this.optionsClickListener = optionsClickListener;
        this.checkboxClickListener = checkboxClickListener;
    }

    // update the adapter's knowledge of selected items
    @SuppressLint("NotifyDataSetChanged")
    public void setSelectedTaskIdsForBulk(List<Task> selectedTasks) {
        this.selectedTaskIdsForBulkAction.clear();
        for (Task task : selectedTasks) {
            this.selectedTaskIdsForBulkAction.add(task.getId());
        }
        notifyDataSetChanged();
    }

    public void clearSelectedTaskIdsForBulk() {
        this.selectedTaskIdsForBulkAction.clear();
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task currentTask = getItem(position);
        if (currentTask != null) {
            boolean isSelectedForBulk = selectedTaskIdsForBulkAction.contains(currentTask.getId());
            holder.bind(currentTask, taskClickListener, optionsClickListener, checkboxClickListener, isSelectedForBulk);
        }
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView descriptionTextView;
        TextView timeTextView;
        ImageView clockIconImageView;
        // TextView tagTextView; // Replaced by categoryChip
        com.google.android.material.chip.Chip categoryChip;
        View priorityDotView;
        CheckBox taskCheckbox;
        ImageButton optionsButton;
        private boolean currentIsSelectedForBulk = false;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.tv_task_title);
            descriptionTextView = itemView.findViewById(R.id.tv_task_description);
            timeTextView = itemView.findViewById(R.id.tv_task_time);
            clockIconImageView = itemView.findViewById(R.id.iv_clock_icon);
            categoryChip = itemView.findViewById(R.id.chip_category);
            priorityDotView = itemView.findViewById(R.id.view_priority);
            taskCheckbox = itemView.findViewById(R.id.cb_task_complete);
            optionsButton = itemView.findViewById(R.id.btn_more_options);


            if (categoryChip == null) System.err.println("ViewHolder: categoryChip is NULL");
            if (priorityDotView == null) System.err.println("ViewHolder: priorityDotView is NULL");
            // Add other null checks if needed
        }

        public void bind(final Task task, final OnTaskClickListener taskClickListener,
                         final OnTaskOptionsClickListener optionsClickListener,
                         final OnTaskCheckboxClickListener checkboxClickListener,
                         boolean isActuallySelectedForBulk) {

            if (titleTextView != null) titleTextView.setText(task.getTitle());
            if (descriptionTextView != null) {
                if (task.getDescription() != null && !task.getDescription().isEmpty()) {
                    descriptionTextView.setText(task.getDescription());
                    descriptionTextView.setVisibility(View.VISIBLE);
                } else {
                    descriptionTextView.setVisibility(View.GONE); // Hide if no description
                }
            }


            // Time
            if (timeTextView != null) {
                if (task.getReminderDateTime() != null) {
                    timeTextView.setText(task.getReminderDateTime().format(DateTimeFormatter.ofPattern("h:mm a")));
                } else if (task.getDueDate() != null) {
                    timeTextView.setText(task.getDueDate().format(DateTimeFormatter.ofPattern("MMM dd")));
                } else {
                    timeTextView.setText("No date");
                }
            }
            if (clockIconImageView != null && timeTextView != null) {
                clockIconImageView.setVisibility(timeTextView.getText().toString().equals("No date") || timeTextView.getText().toString().isEmpty() ? View.GONE : View.VISIBLE);
            }

            // Category/Tag
            if (categoryChip != null) {
                if (task.getCategory() != null && !task.getCategory().isEmpty()) {
                    categoryChip.setText(task.getCategory());
                    // TODO: Set chip background/stroke color based on category using ColorStateList
                    // Example: categoryChip.setChipBackgroundColor(ColorStateList.valueOf(ContextCompat.getColor(itemView.getContext(), R.color.academic_color)));
                    categoryChip.setVisibility(View.VISIBLE);
                } else {
                    categoryChip.setVisibility(View.GONE);
                }
            }

            // Priority Dot
            if (priorityDotView != null) {
                if (task.getPriority() != null) {
                    priorityDotView.setBackgroundColor(getPriorityColor(itemView.getContext(), task.getPriority()));
                    priorityDotView.setVisibility(View.VISIBLE);
                } else {
                    priorityDotView.setVisibility(View.GONE);
                }
            }



            // check box
            this.currentIsSelectedForBulk = isActuallySelectedForBulk;
            if (taskCheckbox != null) {
                taskCheckbox.setOnCheckedChangeListener(null);
                taskCheckbox.setChecked(isActuallySelectedForBulk); // Set checkbox based on this
                taskCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                    if (checkboxClickListener != null) {
                        // The ViewHolder itself shouldn't modify isActuallySelectedForBulk directly here.
                        // It just reports the change. The Fragment will update the main list
                        // and then tell the adapter about the new selected set.
                        checkboxClickListener.onTaskSelectionChanged(task, isChecked);
                    }
                });

            }

            // Visual cue for selection (optional)
            itemView.setBackgroundColor(isActuallySelectedForBulk ?
                    ContextCompat.getColor(itemView.getContext(), R.color.priority_low_green) :
                    ContextCompat.getColor(itemView.getContext(), android.R.color.transparent));


            if (titleTextView != null && descriptionTextView != null) {
                if (task.getStatus() == Task.Status.COMPLETED) {
                    titleTextView.setPaintFlags(titleTextView.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
                    descriptionTextView.setPaintFlags(descriptionTextView.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
                } else {
                    titleTextView.setPaintFlags(titleTextView.getPaintFlags() & (~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG));
                    descriptionTextView.setPaintFlags(descriptionTextView.getPaintFlags() & (~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG));
                }
            }



            // Click listeners
            itemView.setOnClickListener(v -> {
                if (taskClickListener != null) taskClickListener.onTaskClick(task);
            });
            if (optionsButton != null) {
                optionsButton.setOnClickListener(v -> {
                    if (optionsClickListener != null) optionsClickListener.onTaskOptionsClick(task, v);
                });
            }

            // Strikethrough for completed tasks
            if (titleTextView != null && descriptionTextView != null) { // Null checks for safety
                if (task.getStatus() == Task.Status.COMPLETED) {
                    titleTextView.setPaintFlags(titleTextView.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
                    descriptionTextView.setPaintFlags(descriptionTextView.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
                } else {
                    titleTextView.setPaintFlags(titleTextView.getPaintFlags() & (~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG));
                    descriptionTextView.setPaintFlags(descriptionTextView.getPaintFlags() & (~android.graphics.Paint.STRIKE_THRU_TEXT_FLAG));
                }
            }

        }

        private int getPriorityColor(Context context, Task.Priority priority) {
            if (priority == null) return ContextCompat.getColor(context, android.R.color.transparent);

            switch (priority) {
                case LOW:    return ContextCompat.getColor(context, R.color.priority_low_green);
                case MEDIUM: return ContextCompat.getColor(context, R.color.priority_medium_orange);
                case HIGH:   return ContextCompat.getColor(context, R.color.priority_high_red);
                case URGENT: return ContextCompat.getColor(context, R.color.priority_urgent_dark_red);
                default:     return ContextCompat.getColor(context, android.R.color.darker_gray);
            }
        }
    }




    // DiffUtil helps ListAdapter efficiently update the list
    private static final DiffUtil.ItemCallback<Task> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<Task>() {
                @Override
                public boolean areItemsTheSame(@NonNull Task oldItem, @NonNull Task newItem) {
                    return oldItem.getId().equals(newItem.getId());
                }

                @SuppressLint("DiffUtilEquals")
                @Override
                public boolean areContentsTheSame(@NonNull Task oldItem, @NonNull Task newItem) {
                    // Implement a more thorough check if needed, e.g., Objects.equals(oldItem, newItem)
                    // For now, comparing titles and descriptions is a good start.
                    return oldItem.getTitle().equals(newItem.getTitle()) &&
                            Objects.equals(oldItem.getDescription(), newItem.getDescription()) &&
                            oldItem.getStatus() == newItem.getStatus() &&
                            Objects.equals(oldItem.getReminderDateTime(), newItem.getReminderDateTime()) &&
                            Objects.equals(oldItem.getPriority(), newItem.getPriority()) &&
                            Objects.equals(oldItem.getCategory(), newItem.getCategory());
                }
            };
}
