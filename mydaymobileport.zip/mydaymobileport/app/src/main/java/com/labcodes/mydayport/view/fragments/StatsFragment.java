package com.labcodes.mydayport.view.fragments;

import android.graphics.Color; // Use android.graphics.Color
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter; // For bar chart X-axis labels
import com.github.mikephil.charting.formatter.PercentFormatter; // For pie chart percentage
import com.github.mikephil.charting.utils.ColorTemplate; // For chart colors

import com.labcodes.mydayport.MainActivity;
import com.labcodes.mydayport.R;
import com.labcodes.mydayport.model.Task;
import com.labcodes.mydayport.services.TaskService;
// Assuming DailyCompletionStat and PriorityCountStat are simple POJOs
// If TaskService returns Map directly, adapt accordingly.

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.LinkedHashMap; // To maintain order for charts

public class StatsFragment extends Fragment {

    private TaskService taskService;
    private BarChart barChartDailyCompletion;
    private PieChart pieChartPriorityDistribution;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public StatsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() instanceof MainActivity) {
            taskService = ((MainActivity) getActivity()).getTaskService();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_stats, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        barChartDailyCompletion = view.findViewById(R.id.barChartDailyCompletion);
        pieChartPriorityDistribution = view.findViewById(R.id.pieChartPriorityDistribution);

        loadAndDisplayCharts();
    }

    private void loadAndDisplayCharts() {
        if (taskService == null) {
            System.err.println("StatsFragment: TaskService is null.");
            return;
        }

        // --- Chart 1: Tasks Completed Per Day (Last 7 Days) ---
        executor.execute(() -> {
            Map<LocalDate, Long> completedData = taskService.getTasksCompletedPerDayForLastNDays(7);
            mainHandler.post(() -> setupDailyCompletionBarChart(completedData));
        });

        // --- Chart 2: Task Distribution by Priority ---
        executor.execute(() -> {
            Map<Task.Priority, Long> priorityData = taskService.getTaskCountByPriority();
            mainHandler.post(() -> setupPriorityPieChart(priorityData));
        });
    }

    private void setupDailyCompletionBarChart(Map<LocalDate, Long> completedData) {
        if (barChartDailyCompletion == null || completedData == null || completedData.isEmpty()) {
            if (barChartDailyCompletion != null) barChartDailyCompletion.clear(); // Clear previous data
            System.err.println("No data for daily completion chart.");
            return;
        }

        List<BarEntry> entries = new ArrayList<>();
        List<String> xAxisLabels = new ArrayList<>();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMM dd");

        List<LocalDate> sortedDates = new ArrayList<>(completedData.keySet());
        Collections.sort(sortedDates);

        for (int i = 0; i < sortedDates.size(); i++) {
            LocalDate date = sortedDates.get(i);
            entries.add(new BarEntry(i, completedData.getOrDefault(date, 0L).floatValue()));
            xAxisLabels.add(date.format(dateFormatter));
        }

        BarDataSet dataSet = new BarDataSet(entries, "Tasks Completed");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS); // Use predefined Material color scheme
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(10f);

        BarData barData = new BarData(dataSet);
        barData.setBarWidth(0.9f); // Adjust bar width

        barChartDailyCompletion.setData(barData);
        barChartDailyCompletion.setFitBars(true); // make the x-axis fit exactly all bars
        barChartDailyCompletion.getDescription().setEnabled(false); // No description text
        barChartDailyCompletion.animateY(1000); // Animation
        barChartDailyCompletion.getLegend().setEnabled(false); // Hide legend if only one series

        XAxis xAxis = barChartDailyCompletion.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xAxisLabels)); // Set custom labels
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setLabelRotationAngle(-45); // Rotate labels

        barChartDailyCompletion.getAxisRight().setEnabled(false); // Hide right Y-axis
        barChartDailyCompletion.getAxisLeft().setAxisMinimum(0f); // Start Y-axis at 0
        barChartDailyCompletion.invalidate(); // Refresh
    }


    private void setupPriorityPieChart(Map<Task.Priority, Long> priorityData) {
        if (pieChartPriorityDistribution == null || priorityData == null || priorityData.isEmpty()) {
            if(pieChartPriorityDistribution != null) pieChartPriorityDistribution.clear();
            System.err.println("No data for priority distribution chart.");
            return;
        }

        List<PieEntry> entries = new ArrayList<>();
        for (Map.Entry<Task.Priority, Long> entry : priorityData.entrySet()) {
            if (entry.getValue() > 0) { // Only add slices for priorities with tasks
                entries.add(new PieEntry(entry.getValue().floatValue(), entry.getKey().name()));
            }
        }
        if(entries.isEmpty()){
            pieChartPriorityDistribution.clear();
            System.err.println("No actual entries to display in pie chart after filtering zeros.");
            pieChartPriorityDistribution.invalidate();
            return;
        }


        PieDataSet dataSet = new PieDataSet(entries, "Priority Distribution");
        // Use predefined Material or other color templates
        ArrayList<Integer> colors = new ArrayList<>();
        for (int c : ColorTemplate.MATERIAL_COLORS) colors.add(c);
        for (int c : ColorTemplate.VORDIPLOM_COLORS) colors.add(c);
        // Add more color templates if needed, or define your own custom color list
        dataSet.setColors(colors);

        dataSet.setValueFormatter(new PercentFormatter(pieChartPriorityDistribution)); // Show percentages
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setSliceSpace(2f); // Space between slices


        PieData pieData = new PieData(dataSet);
        pieChartPriorityDistribution.setData(pieData);
        pieChartPriorityDistribution.setUsePercentValues(true);
        pieChartPriorityDistribution.getDescription().setEnabled(false);
        pieChartPriorityDistribution.setEntryLabelTextSize(10f);
        pieChartPriorityDistribution.setEntryLabelColor(Color.BLACK);
        pieChartPriorityDistribution.setDrawEntryLabels(true); // Show labels on slices
        pieChartPriorityDistribution.setCenterText("Priorities"); // Optional center text
        pieChartPriorityDistribution.animateY(1000);
        pieChartPriorityDistribution.getLegend().setEnabled(true); // Show legend

        pieChartPriorityDistribution.invalidate(); // Refresh
    }

    public void refreshStatistics() {
        System.out.println("StatsFragment: refreshStatistics called.");
        loadAndDisplayCharts(); // Internally calls your chart loading logic
    }
}