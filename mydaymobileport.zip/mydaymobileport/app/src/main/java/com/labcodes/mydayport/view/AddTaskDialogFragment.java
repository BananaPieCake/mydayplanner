package com.labcodes.mydayport.view;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.app.TimePickerDialog;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.google.android.material.textfield.TextInputEditText;
import com.labcodes.mydayport.MainActivity;
import com.labcodes.mydayport.R;
import com.labcodes.mydayport.model.Task;
import com.labcodes.mydayport.services.TaskService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AddTaskDialogFragment extends DialogFragment {

    // Views - These will be initialized from the inflated dialog_add_task.xml
    private TextInputEditText etTaskTitle;
    private TextInputEditText etTaskDescription;
    private RadioGroup rgPriority;
    private Button btnSave, btnCancel;
    private TextView tvSelectedDueDateDisplay;
    private TextView tvSelectedDueTimeDisplay;
    private Spinner spinnerDueTime;
    private Spinner spinnerCategory;
    private Spinner spinnerRepeat;
    private CheckBox cbSetReminder;
    private TextView tvDialogTitle;
    private TextView tvSelectedCustomTime;

    // Data
    private TaskService taskService;
    private LocalDate selectedDueDate = null;
    private LocalTime selectedDueTime = null;
    private Task taskToEdit = null;
    private boolean isEditMode = false;
    private static final String ARG_TASK_TO_EDIT = "task_to_edit";

    // Listener
    public interface AddTaskDialogListener {
        void onTaskAdded(Task newTask);
    }
    private AddTaskDialogListener listener;

    public static AddTaskDialogFragment newInstance(@Nullable Task taskToPassIn) {
        AddTaskDialogFragment fragment = new AddTaskDialogFragment();
        Bundle args = new Bundle();
        if (taskToPassIn != null) {
            args.putSerializable(ARG_TASK_TO_EDIT, taskToPassIn);
        }
        fragment.setArguments(args);
        return fragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_task, null); // Inflate custom layout

        // --- Initialize ALL Views from dialogView ---
        etTaskTitle = dialogView.findViewById(R.id.etTaskTitle);
        etTaskDescription = dialogView.findViewById(R.id.etTaskDescription);
        rgPriority = dialogView.findViewById(R.id.rgPriority);
        btnSave = dialogView.findViewById(R.id.btnSave);
        btnCancel = dialogView.findViewById(R.id.btnCancel);
        tvSelectedDueDateDisplay = dialogView.findViewById(R.id.tvSelectedDueDateDisplay);
        spinnerDueTime = dialogView.findViewById(R.id.spinnerDueTime);
        tvSelectedCustomTime = dialogView.findViewById(R.id.tvSelectedCustomTime);
        spinnerCategory = dialogView.findViewById(R.id.spinnerCategory);
        spinnerRepeat = dialogView.findViewById(R.id.spinnerRepeat);
        cbSetReminder = dialogView.findViewById(R.id.cbSetReminder);
        tvDialogTitle = dialogView.findViewById(R.id.tvDialogTitle);

        // see if edit or not
        if (getArguments() != null && getArguments().containsKey(ARG_TASK_TO_EDIT)) {
            this.taskToEdit = (Task) getArguments().getSerializable(ARG_TASK_TO_EDIT);
            this.isEditMode = (this.taskToEdit != null);
        } else {
            this.isEditMode = false;
            this.taskToEdit = null;
        }

        // --- Get TaskService and Listener ---
        if (getActivity() instanceof MainActivity) {
            this.taskService = ((MainActivity) getActivity()).getTaskService();
            this.listener = (AddTaskDialogListener) getActivity();
        } else {
            System.err.println("AddTaskDialogFragment: Hosting activity setup error.");
            // Consider throwing an exception or disabling save if service/listener are critical
        }

        // --- Populate Spinners ---
        populateDueTimeSpinner();
        populateCategorySpinner();
        populateRepeatSpinner();
        populateSpinnersAndCustomTime();

        // --- Setup Date Picker Click ---
        setupDatePicker();

        // --- Setup Button Click Listeners ---
        setupActionButtons();

        if (isEditMode) {
            if (tvDialogTitle != null) {
//                tvDialogTitle.setVisibility(View.GONE);
                tvDialogTitle.setText("Edit Details");
            }
            if (btnSave != null) btnSave.setText("Save Changes");
            populateFormForEdit();
        } else {

            if (tvDialogTitle != null) {
                tvDialogTitle.setText("Add New Task");
                tvDialogTitle.setVisibility(View.VISIBLE);
            }
            if (btnSave != null) btnSave.setText("Save Task");
        }

        builder.setView(dialogView);

        return builder.create();
    }

    private void populateFormForEdit() {
        if (taskToEdit == null || !isEditMode) return;

        etTaskTitle.setText(taskToEdit.getTitle());
        etTaskDescription.setText(taskToEdit.getDescription());

        // Due Date
        selectedDueDate = taskToEdit.getDueDate(); // Store it
        if (selectedDueDate != null) {
            tvSelectedDueDateDisplay.setText(selectedDueDate.format(DateTimeFormatter.ofPattern("MMM dd, yyyy")));
        } else {
            tvSelectedDueDateDisplay.setText("Select Due Date");
        }

        // Due Time
        selectedDueTime = taskToEdit.getReminderDateTime() != null ? taskToEdit.getReminderDateTime().toLocalTime() : null;
        if (selectedDueTime != null) {
            String formattedTime = selectedDueTime.format(DateTimeFormatter.ofPattern("h:mm a"));
            // Find the item in the spinner and select it
            for (int i = 0; i < spinnerDueTime.getAdapter().getCount(); i++) {
                if (formattedTime.equals(spinnerDueTime.getItemAtPosition(i).toString())) {
                    spinnerDueTime.setSelection(i);
                    break;
                }
            }
        } else {
            spinnerDueTime.setSelection(0); // "Select Time"
        }

        // Priority
        Task.Priority priority = taskToEdit.getPriority();
        if (priority != null) {
            if (priority == Task.Priority.LOW) rgPriority.check(R.id.rbLow);
            else if (priority == Task.Priority.MEDIUM) rgPriority.check(R.id.rbMedium);
            else if (priority == Task.Priority.HIGH) rgPriority.check(R.id.rbHigh);
            // else if (priority == Task.Priority.URGENT) rgPriority.check(R.id.rbUrgent); // If you have it
        } else {
            rgPriority.check(R.id.rbMedium); // Default
        }

        // Category
        if (taskToEdit.getCategory() != null && !taskToEdit.getCategory().isEmpty()) {
            // Find the item in the spinner and select it
            for (int i = 0; i < spinnerCategory.getAdapter().getCount(); i++) {
                if (taskToEdit.getCategory().equals(spinnerCategory.getItemAtPosition(i).toString())) {
                    spinnerCategory.setSelection(i);
                    break;
                }
            }
        } else {
            spinnerCategory.setSelection(0); // "Select Category"
        }

        // Repeat (similar logic for spinnerRepeat if implemented)
        // ...

        // Set Reminder CheckBox
        cbSetReminder.setChecked(taskToEdit.getReminderDateTime() != null);
    }

    private void populateSpinnersAndCustomTime() {
        populateCategorySpinner();
        populateRepeatSpinner();
        populateDueTimePresetsSpinner(); // New method for presets
        setupCustomTimePickerTrigger();  // New method for the custom time TextView
    }

    private void populateDueTimePresetsSpinner() {
        if (spinnerDueTime == null) { System.err.println("spinnerDueTime is NULL!"); return; }

        List<String> timePresets = new ArrayList<>();
        timePresets.add("Select Time Preset"); // Placeholder
        timePresets.add("Morning (8:00 AM)");
        timePresets.add("Afternoon (1:00 PM)");
        timePresets.add("Evening (6:00 PM)");
        timePresets.add("Night (9:00 PM)");
        timePresets.add("Custom..."); // Option to trigger custom time picker

        ArrayAdapter<String> timeAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, timePresets);
        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDueTime.setAdapter(timeAdapter);
        spinnerDueTime.setSelection(0);

        spinnerDueTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedPreset = (String) parent.getItemAtPosition(position);
                if ("Custom...".equals(selectedPreset)) {
                    tvSelectedCustomTime.setVisibility(View.VISIBLE);
                    tvSelectedCustomTime.setText("Set Custom Time");
                    selectedDueTime = null;
                } else if (position > 0) {
                    tvSelectedCustomTime.setVisibility(View.GONE);

                    try {
                        String timePart = selectedPreset.substring(selectedPreset.indexOf("(") + 1, selectedPreset.indexOf(")"));
                        selectedDueTime = LocalTime.parse(timePart, DateTimeFormatter.ofPattern("h:mm a"));
                        tvSelectedCustomTime.setText(selectedDueTime.format(DateTimeFormatter.ofPattern("h:mm a"))); // Show it in the (now hidden) custom field too for consistency
                    } catch (Exception e) {
                        selectedDueTime = null;
                        System.err.println("Error parsing preset time: " + selectedPreset);
                    }
                } else { // "Select Time Preset"
                    tvSelectedCustomTime.setVisibility(View.GONE);
                    selectedDueTime = null;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                tvSelectedCustomTime.setVisibility(View.GONE);
                selectedDueTime = null;
            }
        });
    }

    private void setupCustomTimePickerTrigger() {
        if (tvSelectedCustomTime == null) { System.err.println("tvSelectedCustomTime is NULL!"); return; }

        // Initial state for tvSelectedCustomTime (display based on selectedDueTime if editing)
        if (selectedDueTime != null) {
            tvSelectedCustomTime.setText(selectedDueTime.format(DateTimeFormatter.ofPattern("h:mm a")));
            tvSelectedCustomTime.setVisibility(View.VISIBLE);
            // Also, try to set the spinnerDueTimePresets to "Custom..." if selectedDueTime was from an edit
            if (isEditMode && spinnerDueTime != null) {
                // This logic is tricky: you need to see if selectedDueTime matches a preset.
                // If not, assume it was custom.
                boolean matchesPreset = false;
                // ... loop through spinnerDueTimePresets items to check ...
                if (!matchesPreset) spinnerDueTime.setSelection(spinnerDueTime.getAdapter().getCount() -1); // Select "Custom..."
            }
        } else {
            tvSelectedCustomTime.setText("Set Custom Time");
            // Hide it if a preset is selected by default, or if "Select Time Preset" is default
            if (spinnerDueTime != null && spinnerDueTime.getSelectedItemPosition() > 0 &&
                    !"Custom...".equals(spinnerDueTime.getSelectedItem().toString())) {
                tvSelectedCustomTime.setVisibility(View.GONE);
            } else if (spinnerDueTime != null && "Custom...".equals(spinnerDueTime.getSelectedItem().toString())) {
                tvSelectedCustomTime.setVisibility(View.VISIBLE);
            } else {
                tvSelectedCustomTime.setVisibility(View.GONE); // Default if "Select time"
            }
        }


        tvSelectedCustomTime.setOnClickListener(v -> {
            final Calendar c = Calendar.getInstance();
            int hour, minute;
            if (selectedDueTime != null) { // Use current custom time if set
                hour = selectedDueTime.getHour();
                minute = selectedDueTime.getMinute();
            } else { // Default to current time
                hour = c.get(Calendar.HOUR_OF_DAY);
                minute = c.get(Calendar.MINUTE);
            }

            TimePickerDialog timePickerDialog = new TimePickerDialog(requireActivity(),
                    (timePickerView, selectedHour, selectedMinute) -> {
                        selectedDueTime = LocalTime.of(selectedHour, selectedMinute);
                        tvSelectedCustomTime.setText(selectedDueTime.format(DateTimeFormatter.ofPattern("h:mm a")));
                        // Ensure the preset spinner is set to "Custom..." if a custom time is picked
                        if (spinnerDueTime != null) {
                            for(int i=0; i<spinnerDueTime.getAdapter().getCount(); ++i) {
                                if("Custom...".equals(spinnerDueTime.getItemAtPosition(i).toString())) {
                                    spinnerDueTime.setSelection(i, false); // set false to not trigger onItemSelected
                                    break;
                                }
                            }
                        }
                    }, hour, minute, false);
            timePickerDialog.show();
        });
    }

    private void populateDueTimeSpinner() {
        if (spinnerDueTime == null) {
            System.err.println("populateDueTimeSpinner: spinnerDueTime is NULL!");
            return;
        }
        List<String> timeSlots = new ArrayList<>();
        timeSlots.add("Select Time");
        for (int hour = 0; hour < 24; hour++) {
            for (int minute = 0; minute < 60; minute += 30) {
                LocalTime time = LocalTime.of(hour, minute);
                timeSlots.add(time.format(DateTimeFormatter.ofPattern("h:mm a")));
            }
        }
        ArrayAdapter<String> timeAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, timeSlots);
        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDueTime.setAdapter(timeAdapter);
        spinnerDueTime.setSelection(0);
        System.out.println("DueTime Spinner populated with " + timeAdapter.getCount() + " items.");

        spinnerDueTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedTimeStr = (String) parent.getItemAtPosition(position);
                if (position > 0) {
                    try {
                        selectedDueTime = LocalTime.parse(selectedTimeStr, DateTimeFormatter.ofPattern("h:mm a"));
                    } catch (DateTimeParseException e) {
                        selectedDueTime = null;
                        System.err.println("Error parsing time: " + selectedTimeStr);
                    }
                } else {
                    selectedDueTime = null;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { selectedDueTime = null; }
        });
    }

    private void populateCategorySpinner() {
        if (spinnerCategory == null) {
            System.err.println("populateCategorySpinner: spinnerCategory is NULL!");
            return;
        }
        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(requireContext(),
                R.array.task_categories, android.R.layout.simple_spinner_item);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(categoryAdapter);
        spinnerCategory.setSelection(0);
        System.out.println("Category Spinner populated with " + categoryAdapter.getCount() + " items.");
    }

    private void populateRepeatSpinner() {
        if (spinnerRepeat == null) {
            System.err.println("populateRepeatSpinner: spinnerRepeat is NULL!");
            return;
        }
        ArrayAdapter<CharSequence> repeatAdapter = ArrayAdapter.createFromResource(requireContext(),
                R.array.repeat_options, android.R.layout.simple_spinner_item);
        repeatAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRepeat.setAdapter(repeatAdapter);
        spinnerRepeat.setSelection(0);
        System.out.println("Repeat Spinner populated with " + repeatAdapter.getCount() + " items.");
    }

    private void setupDatePicker() {
        if (tvSelectedDueDateDisplay == null) {
            System.err.println("setupDatePicker: tvSelectedDueDateDisplay is NULL!");
            return;
        }
        // Initialize display text
        if (selectedDueDate != null) {
            tvSelectedDueDateDisplay.setText(selectedDueDate.format(DateTimeFormatter.ofPattern("MMM dd, yyyy")));
        } else {
            tvSelectedDueDateDisplay.setText("Select Due Date");
        }

        tvSelectedDueDateDisplay.setOnClickListener(v -> {
            final Calendar c = Calendar.getInstance();
            int year, month, day;
            if (selectedDueDate != null) {
                year = selectedDueDate.getYear();
                month = selectedDueDate.getMonthValue() - 1;
                day = selectedDueDate.getDayOfMonth();
            } else {
                year = c.get(Calendar.YEAR);
                month = c.get(Calendar.MONTH);
                day = c.get(Calendar.DAY_OF_MONTH);
            }
            DatePickerDialog datePickerDialog = new DatePickerDialog(requireActivity(),
                    (pickerView, selectedYear, monthOfYear, dayOfMonth) -> {
                        selectedDueDate = LocalDate.of(selectedYear, monthOfYear + 1, dayOfMonth);
                        tvSelectedDueDateDisplay.setText(selectedDueDate.format(DateTimeFormatter.ofPattern("MMM dd, yyyy")));
                    }, year, month, day);
            datePickerDialog.show();
        });
    }

    private void setupActionButtons() {
        if (btnSave == null || btnCancel == null) {
            System.err.println("setupActionButtons: Save or Cancel button is NULL!");
            return;
        }
        btnSave.setOnClickListener(v -> {
            String title = etTaskTitle.getText().toString().trim();
            String description = etTaskDescription.getText().toString().trim();
            LocalDate actualDueDate = this.selectedDueDate; // From DatePickerDialog
            LocalTime actualDueTime = this.selectedDueTime; // From Time Spinner

            if (title.isEmpty()) {
                etTaskTitle.setError("Title cannot be empty");
                return;
            }
            if (actualDueDate == null) {
                Toast.makeText(getContext(), "Please select a Due Date.", Toast.LENGTH_SHORT).show();
                return;
            }

            Task.Priority priority = Task.Priority.MEDIUM;
            int selectedPriorityId = rgPriority.getCheckedRadioButtonId();
            if (selectedPriorityId == R.id.rbLow) priority = Task.Priority.LOW;
            else if (selectedPriorityId == R.id.rbMedium) priority = Task.Priority.MEDIUM;
            else if (selectedPriorityId == R.id.rbHigh) priority = Task.Priority.HIGH;

            String category = null;
            if (spinnerCategory.getSelectedItemPosition() > 0) {
                category = spinnerCategory.getSelectedItem().toString();
            }

            // String repeatOption = spinnerRepeat.getSelectedItem().toString(); // For later

            boolean wantsReminder = cbSetReminder.isChecked();
            LocalDateTime reminderDateTime = null;
            if (wantsReminder) {
                if (actualDueTime != null) {
                    reminderDateTime = LocalDateTime.of(actualDueDate, actualDueTime);
                } else {
                    reminderDateTime = actualDueDate.atTime(9, 0); // Default
                }
            }

            // --- Logic for ADD vs EDIT ---
            if (taskService == null) {
                Toast.makeText(getContext(), "Internal error: Service not available.", Toast.LENGTH_SHORT).show();
                System.err.println("AddTaskDialogFragment: taskService is null in btnSave listener!");
                return;
            }

            if (isEditMode && taskToEdit != null) {
                // --- EDIT MODE ---
                System.out.println("AddTaskDialogFragment: Attempting to SAVE EDITED task ID: " + taskToEdit.getId());
                taskToEdit.setTitle(title);
                taskToEdit.setDescription(description);
                taskToEdit.setDueDate(actualDueDate);
                taskToEdit.setPriority(priority);
                taskToEdit.setCategory(category);
                taskToEdit.setReminderDateTime(reminderDateTime);
                // taskToEdit.setStatus(...); // If status can be changed in edit dialog
                // taskToEdit.setReminded(...); // Usually not set by user in edit dialog

                Task updatedTask = taskService.save(taskToEdit);

                if (updatedTask != null) {
                    System.out.println("Task updated successfully: " + updatedTask.getTitle());
                    if (listener != null) {

                        listener.onTaskAdded(updatedTask);
                    }
                    dismiss();
                } else {
                    Toast.makeText(getContext(), "Failed to update task.", Toast.LENGTH_SHORT).show();
                }

            } else {
                // --- ADD MODE ---
                System.out.println("AddTaskDialogFragment: Attempting to CREATE NEW task.");
                Task newTask = taskService.createTask(title, description, actualDueDate);
                if (newTask != null) {
                    newTask.setPriority(priority);
                    newTask.setReminderDateTime(reminderDateTime);
                    newTask.setCategory(category);
                    // Any other fields that are not set by the basic createTask method

                    Task fullySavedTask = taskService.save(newTask); // This second save populates additional fields via UPDATE

                    if (fullySavedTask != null) {
                        System.out.println("Task created and properties set successfully: " + fullySavedTask.getTitle());
                        if (listener != null) {
                            listener.onTaskAdded(fullySavedTask);
                        }
                        dismiss();
                    } else {
                        Toast.makeText(getContext(), "Failed to save additional task properties.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), "Failed to create task in database.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCancel.setOnClickListener(v -> dismiss());
    }


    // You can remove onCreateView and onViewCreated if all setup is in onCreateDialog
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return null; // When using AlertDialog.Builder and setView, this can return null
        // or super.onCreateView which might inflate a default view if not careful.
        // If you want full control without AlertDialog default buttons/title, inflate here and return Dialog in onCreateDialog.
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // If onCreateView returns null, this 'view' parameter might not be what you expect.
        // All view setup is now in onCreateDialog for the AlertDialog.Builder.
    }

}