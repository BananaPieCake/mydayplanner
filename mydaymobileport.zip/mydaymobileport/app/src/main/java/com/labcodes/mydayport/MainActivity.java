package com.labcodes.mydayport;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import android.app.Activity;
import androidx.activity.result.ActivityResultLauncher;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import com.labcodes.mydayport.model.Task;
import com.labcodes.mydayport.repositories.SqliteTaskRepository;
import com.labcodes.mydayport.repositories.TaskRepository;
import com.labcodes.mydayport.services.MyReminderJobService;
import com.labcodes.mydayport.services.TaskService;
import com.labcodes.mydayport.view.AddTaskDialogFragment;
import com.labcodes.mydayport.view.fragments.ExportFunc;
import com.labcodes.mydayport.view.fragments.ImportFunc;
import com.labcodes.mydayport.view.fragments.ProjectsFragment;
import com.labcodes.mydayport.view.fragments.StatsFragment;
import com.labcodes.mydayport.view.fragments.TodayFragment;
import com.labcodes.mydayport.view.fragments.WeekFragment;

// for reminder service
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

// for request
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity
        implements AddTaskDialogFragment.AddTaskDialogListener {

    private Toolbar toolbar;
    private TaskService taskService;
    private BottomNavigationView bottomNavigationView;
    // request
    private static final int NOTIFICATION_PERMISSION_REQUEST_CODE = 123;
    public static final int REMINDER_JOB_ID = 1001;

    private ActivityResultLauncher<String> createJsonFileLauncher;
    private ActivityResultLauncher<Intent> importTasksLauncher;
    private static final String TAG = "MainActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        scheduleReminderJob(this);
        requestNotificationPermission();

        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if(getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Today's Tasks");
        }

        bottomNavigationView = findViewById(R.id.bottom_navigation_view);

        // --- Initialize Backend/Service ---
        TaskRepository taskRepository = new SqliteTaskRepository(getApplicationContext());
        this.taskService = new TaskService(taskRepository);
        // For EXPORTING (Saving a file)
        createJsonFileLauncher = registerForActivityResult( // For EXPORTING
                new ActivityResultContracts.CreateDocument("application/json"),
                uri -> {
                    if (uri != null) {
                        if (tasksToExportHolder != null && !tasksToExportHolder.isEmpty()) {
                            writeJsonToUri(uri, tasksToExportHolder);
                        } else {
                            Toast.makeText(this, "No data to write for export.", Toast.LENGTH_SHORT).show();
                        }
                        tasksToExportHolder = null; // Clear temp holder
                    } else {
                        Toast.makeText(this, "Export cancelled or file not selected.", Toast.LENGTH_SHORT).show();
                        tasksToExportHolder = null; // Clear temp holder
                    }
                }
        );

        importTasksLauncher = registerForActivityResult( // For IMPORTING
                new ActivityResultContracts.StartActivityForResult(), // Using StartActivityForResult for ACTION_OPEN_DOCUMENT
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        if (uri != null) {
                            Log.d(TAG, "Import: File selected by user: " + uri.toString()); // Use toString() for URI logging
                            performActualImport(uri);
                        } else {
                            Toast.makeText(this, "Import: No file selected.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Import cancelled.", Toast.LENGTH_SHORT).show();
                    }
                });
        // --- Setup Bottom Navigation ---
        setupBottomNavigation();

        // --- Load Initial Fragment ---
        if (savedInstanceState == null) { // Only on first create
            loadFragment(new TodayFragment(), "Today's Tasks"); // Default to TodayFragment
            bottomNavigationView.setSelectedItemId(R.id.nav_today); // Highlight default item
        }
    }

    public TaskService getTaskService() {
        return this.taskService;
    }

    private void setupBottomNavigation() {
        if (bottomNavigationView == null) return;

        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            String title = "";
            int itemId = item.getItemId();

            if (itemId == R.id.nav_today) {
                selectedFragment = new TodayFragment();
                title = "Today's Tasks";
            } else if (itemId == R.id.nav_week) {
                selectedFragment = new WeekFragment();
                title = "Week View";
            } else if (itemId == R.id.nav_projects) {
                selectedFragment = new ProjectsFragment();
                title = "Projects";
            } else if (itemId == R.id.nav_stats) {
                selectedFragment = new StatsFragment();
                title = "Statistics";
            }
//            else if (itemId == R.id.nav_import) {
//                selectedFragment = new ImportFunc();
//                title = "Import";
//            } else if (itemId == R.id.nav_export) {
//                selectedFragment = new ExportFunc();
//                title = "Export";
//            }

            if (selectedFragment != null) {
                loadFragment(selectedFragment, title);
            }
            return true;
        });
    }

    private void loadFragment(Fragment fragment, String title) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.nav_host_fragment_container, fragment)
                .commit();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }


    // Implementation of AddTaskDialogFragment.AddTaskDialogListener
    @Override
    public void onTaskAdded(Task newTask) {
        System.out.println("MainActivity: Task added/updated - " + newTask.getTitle());
        // The currently visible fragment should handle refreshing its own list
        // One way is to find the current fragment and call a refresh method on it.
        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_container);
        if (currentFragment instanceof TodayFragment) {
            ((TodayFragment) currentFragment).loadTasksForFragment();
        } else if (currentFragment instanceof WeekFragment) {
             ((WeekFragment) currentFragment).loadTasksForFragment();
        } else if (currentFragment instanceof ProjectsFragment) {
            ((ProjectsFragment) currentFragment).loadTasksForFragment();
        } else if (currentFragment instanceof StatsFragment) {
            ((StatsFragment) currentFragment).refreshStatistics();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main_menu, menu);
        System.out.println("MainActivity: onCreateOptionsMenu called and main_menu inflated.");
        return true;
    }

    // for filter and import export function
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        System.out.println("MainActivity: onOptionsItemSelected - Clicked item ID: " + item.getTitle());

        if (id == R.id.action_filter) {

            Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_container);
            if (currentFragment instanceof TodayFragment) {
                ((TodayFragment) currentFragment).showFilterOptions();
            } else if (currentFragment instanceof WeekFragment) {
                // ((WeekFragment) currentFragment).showFilterOptions();
            }
            return true;
        }
        if (id == R.id.action_import_data) {
            handleImportTasksTrigger(); // launch the file picker
            return true;
        } else if (id == R.id.action_export_data) {
            handleExportTasksTrigger(); // fetch data then launch file picker
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // reminder service:

    private void scheduleReminderJob(Context context) {
        ComponentName componentName = new ComponentName(context, MyReminderJobService.class);
        JobInfo.Builder builder = new JobInfo.Builder(REMINDER_JOB_ID, componentName)
                .setPersisted(true);
        builder.setPeriodic(TimeUnit.MINUTES.toMillis(1));


        // Android 12 (API 31) stricter background restrictions
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (jobScheduler != null) {

            int resultCode = jobScheduler.schedule(builder.build());
            if (resultCode == JobScheduler.RESULT_SUCCESS) {
                Log.d("MainActivity", "Reminder Job (Periodic, 1 min test interval) scheduled successfully.");
            } else {
                Log.e("MainActivity", "Reminder Job scheduling failed. Result code: " + resultCode);
            }
        } else {
            Log.e("MainActivity", "JobScheduler service not found.");
        }
    }

    // requests
    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { // API 33+
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED) {
                // Permission not granted, request it
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_REQUEST_CODE);
            } else {
                // Permission already granted
                Log.d("MainActivity", "Notification permission already granted.");
                scheduleReminderJob(this);
            }
        } else {
            scheduleReminderJob(this);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("MainActivity", "Notification permission granted by user.");
                scheduleReminderJob(this); // Schedule job after permission granted
            } else {
                Log.w("MainActivity", "Notification permission denied by user.");
                Toast.makeText(this, "Notification permission denied. Reminders might not work.", Toast.LENGTH_LONG).show();
            }
        }
    }


    // --- EXPORT LOGIC ---
    private List<Task> tasksToExportHolder = null; // Temp holder for tasks during export

    private void handleExportTasksTrigger() {
        if (taskService == null) {
            Toast.makeText(this, "Task service not available.", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "Preparing data for export...", Toast.LENGTH_SHORT).show();
        Executors.newSingleThreadExecutor().execute(() -> {
            tasksToExportHolder = taskService.getAllTasks();
            new Handler(Looper.getMainLooper()).post(() -> {
                if (tasksToExportHolder == null || tasksToExportHolder.isEmpty()) {
                    Toast.makeText(MainActivity.this, "No tasks to export.", Toast.LENGTH_SHORT).show();
                    tasksToExportHolder = null;
                    return;
                }
                if (createJsonFileLauncher != null) { // Check if initialized
                    createJsonFileLauncher.launch("myday_tasks_export.json");
                } else {
                    Log.e(TAG, "createJsonFileLauncher is not initialized!");
                }
            });
        });
    }


    private void writeJsonToUri(Uri uri, List<Task> tasks) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);

        try (OutputStreamWriter outputStreamWriter =
                     new OutputStreamWriter(getContentResolver().openOutputStream(uri), StandardCharsets.UTF_8)) {
            objectMapper.writeValue(outputStreamWriter, tasks);
            Toast.makeText(this, "Tasks exported successfully!", Toast.LENGTH_LONG).show();
            Log.d(TAG, "Export successful to: " + uri.toString());
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Export Error: File not found for URI - " + uri.toString(), e);
            Toast.makeText(this, "Export Error: Could not open file.", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Log.e(TAG, "Export Error: IOException - " + e.getMessage(), e);
            Toast.makeText(this, "Export Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        } catch (Exception e) { // Catch any other unexpected errors
            Log.e(TAG, "Export Error: Unexpected - " + e.getMessage(), e);
            Toast.makeText(this, "An unexpected error occurred during export.", Toast.LENGTH_LONG).show();
        }
    }


    // --- IMPORT LOGIC ---
    private void handleImportTasksTrigger() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        if (importTasksLauncher != null) { // Check if initialized
            importTasksLauncher.launch(intent);
        } else {
            Log.e(TAG, "importTasksLauncher is not initialized!");
        }
    }
    private void performActualImport(Uri uri) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());

        StringBuilder stringBuilder = new StringBuilder();
        try (InputStream inputStream = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Import Error: File not found for URI - " + uri.toString(), e);
            Toast.makeText(this, "Import Error: File not found.", Toast.LENGTH_LONG).show();
            return;
        } catch (IOException e) {
            Log.e(TAG, "Import Error: IOException reading file - " + e.getMessage(), e);
            Toast.makeText(this, "Import Error: Could not read file.", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            List<Task> importedTasks = objectMapper.readValue(stringBuilder.toString(), new TypeReference<List<Task>>() {});

            if (importedTasks != null && !importedTasks.isEmpty()) {

                // --- Use Android AlertDialog ---
                new AlertDialog.Builder(this)
                        .setTitle("Confirm Import")
                        .setMessage("This will replace ALL existing tasks with the tasks from the file.\nAre you sure you want to continue?")
                        .setPositiveButton("Replace All", (dialog, which) -> {
                            // Perform deletion and import on background thread
                            Executors.newSingleThreadExecutor().execute(() -> {
                                List<Task> currentTasks = taskService.getAllTasks();
                                for (Task task : currentTasks) {
                                    taskService.deleteTask(task.getId());
                                }
                                Log.d(TAG, "All existing tasks deleted for import.");

                                int count = 0;
                                for (Task taskToImport : importedTasks) {
                                    taskService.save(taskToImport); // save should handle insert
                                    count++;
                                }
                                final int finalCount = count;
                                new Handler(Looper.getMainLooper()).post(() -> {
                                    Toast.makeText(MainActivity.this, finalCount + " tasks imported (replaced existing)!", Toast.LENGTH_LONG).show();
                                    refreshCurrentFragment(); // Refresh the displayed list
                                });
                            });
                        })
                        .setNegativeButton("Cancel", null)
                        .show();

            } else {
                Toast.makeText(this, "No tasks found in the file or file is empty.", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            Log.e(TAG, "Import Error: Could not parse JSON - " + e.getMessage(), e);
            Toast.makeText(this, "Import Error: Invalid JSON file format.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    // Helper to refresh the currently visible fragment's task list
    private void refreshCurrentFragment() {
        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_container);
        if (currentFragment instanceof TodayFragment) {
            ((TodayFragment) currentFragment).loadTasksForFragment();
        } else if (currentFragment instanceof WeekFragment) {
            ((WeekFragment) currentFragment).loadTasksForFragment();
        } else if (currentFragment instanceof ProjectsFragment) {
            ((ProjectsFragment) currentFragment).loadTasksForFragment();
        }
        // Add other fragments if they display tasks
    }


}
