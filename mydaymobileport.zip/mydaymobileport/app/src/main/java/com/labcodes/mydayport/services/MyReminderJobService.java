package com.labcodes.mydayport.services;

import android.annotation.SuppressLint;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Handler;
import android.os.Looper;
import android.util.Log; // Use Android Log

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.app.PendingIntent;
import android.content.Intent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

import com.labcodes.mydayport.MainActivity; // To open app on notification click
import com.labcodes.mydayport.R; // For notification icon
import com.labcodes.mydayport.model.Task;
import com.labcodes.mydayport.repositories.SqliteTaskRepository; // Need an instance or way to get it
import com.labcodes.mydayport.repositories.TaskRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@SuppressLint("SpecifyJobSchedulerIdRange") // If targetSdk is 31+ for Job ID
public class MyReminderJobService extends JobService {
    private static final String TAG = "MyReminderJobService";
    private boolean jobCancelled = false;
    private TaskService taskService;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private static final String CHANNEL_ID = "task_reminder_channel";
    private static final int NOTIFICATION_ID_BASE = 1000; // Base for unique notification IDs


    @Override
    public void onCreate() {
        super.onCreate();
        TaskRepository repository = new SqliteTaskRepository(getApplicationContext());
        taskService = new TaskService(repository);
        createNotificationChannel();
        Log.d(TAG, "JobService created.");
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        Log.d(TAG, "Job started");
        jobCancelled = false;
        doBackgroundWork(params);
        return true; // Indicates that the job is still doing work on a separate thread
    }

    private void doBackgroundWork(final JobParameters params) {
        executor.execute(() -> {
            if (jobCancelled) {
                return;
            }
            Log.d(TAG, "Checking for reminders in background...");
            if (taskService == null) {
                Log.e(TAG, "TaskService is null, cannot check reminders.");
                jobFinished(params, false); // false because work did not complete successfully
                return;
            }

            List<Task> allTasks = taskService.getActiveTasks(); // Get active tasks
            LocalDateTime now = LocalDateTime.now();
            int notificationCount = 0;

            for (Task task : allTasks) {
                if (jobCancelled) break;

                if (task.getReminderDateTime() != null &&
                        !task.isReminded() &&
                        (task.getReminderDateTime().isBefore(now) || task.getReminderDateTime().isEqual(now))) {

                    Log.i(TAG, "Reminder due for: " + task.getTitle());
                    showNotification(task, notificationCount++);
                    task.setReminded(true);
                    taskService.save(task); // Persist the reminded state
                }
            }
            Log.d(TAG, "Reminder check finished. Fired " + notificationCount + " notifications.");
            jobFinished(params, false); // false means the job does not need to be rescheduled by system
        });
    }


    private void showNotification(Task task, int uniqueNotificationIdOffset) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification_placeholder)
                .setContentTitle("Task Reminder: " + task.getTitle())
                .setContentText(task.getDescription() != null && !task.getDescription().isEmpty() ?
                        task.getDescription() : "Your task is due for a reminder.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        try {
            notificationManager.notify(NOTIFICATION_ID_BASE + uniqueNotificationIdOffset, builder.build());
            Log.d(TAG, "Notification shown for: " + task.getTitle());
        } catch (SecurityException e){
            Log.e(TAG, "Notification permission might be missing (Android 13+): " + e.getMessage());
            // On Android 13+, you need to request POST_NOTIFICATIONS permission
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.reminder_channel_name);
            String description = getString(R.string.reminder_channel_description);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
            Log.d(TAG, "Notification channel created.");
        }
    }


    @Override
    public boolean onStopJob(JobParameters params) {
        Log.d(TAG, "Job cancelled/stopped by system");
        jobCancelled = true;
        // Return true to reschedule if the job was interrupted by the system before completion
        // Return false if the work is done or should not be rescheduled.
        return true; // Reschedule if stopped prematurely
    }
}
