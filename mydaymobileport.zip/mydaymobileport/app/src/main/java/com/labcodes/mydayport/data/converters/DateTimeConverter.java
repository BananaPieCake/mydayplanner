package com.labcodes.mydayport.data.converters;

import androidx.room.TypeConverter;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

public class DateTimeConverter {
    @TypeConverter
    public static Long fromLocalDateTime(LocalDateTime dateTime) {
        return dateTime == null ? null : dateTime.toEpochSecond(ZoneOffset.UTC) * 1000; // Store as millis
    }

    @TypeConverter
    public static LocalDateTime toLocalDateTime(Long epochMilli) {
        return epochMilli == null ? null : LocalDateTime.ofEpochSecond(epochMilli / 1000,
                (int) (epochMilli % 1000) * 1_000_000,
                ZoneOffset.UTC);
    }
}