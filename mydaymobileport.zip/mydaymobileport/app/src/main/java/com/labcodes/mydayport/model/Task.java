package com.labcodes.mydayport.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.TypeConverters;

import com.labcodes.mydayport.data.converters.DateConverter;
import com.labcodes.mydayport.data.converters.DateTimeConverter;
import com.labcodes.mydayport.data.converters.PriorityConverter;
import com.labcodes.mydayport.data.converters.StatusConverter;


/**
 *
 * @author Miguel Pogi
 */

@Entity(tableName = "tasks")
@TypeConverters({DateConverter.class, DateTimeConverter.class, PriorityConverter.class, StatusConverter.class}) // Ensure these exist and are correct
public class Task implements Serializable {

    public enum Priority { LOW, MEDIUM, HIGH, URGENT }
    public enum Status { PENDING, IN_PROGRESS, COMPLETED, POSTPONED } // Corrected spelling

    @PrimaryKey
    @androidx.annotation.NonNull
    @ColumnInfo(name = "id")
    private String id;

    @ColumnInfo(name = "title")
    private String title;

    @ColumnInfo(name = "description")
    private String description;

    @ColumnInfo(name = "creation_timestamp")
    private LocalDateTime creationTimestamp; // RENAMED for consistency

    @ColumnInfo(name = "due_date")
    private LocalDate dueDate;

    @ColumnInfo(name = "reminded")
    private boolean reminded;

    @ColumnInfo(name = "reminder_date_time")
    private LocalDateTime reminderDateTime;

    @ColumnInfo(name = "priority") // Room will use PriorityConverter
    private Priority priority;

    @ColumnInfo(name = "status")   // Room will use StatusConverter
    private Status status;

    @ColumnInfo(name = "category")
    private String category;

    // No-argument constructor for Room and Jackson
    public Task() {
        // Initialize with sensible defaults Room can use before setters
        this.id = UUID.randomUUID().toString(); // Provide a default ID, Room will overwrite if PK
        this.status = Status.PENDING;
        this.priority = Priority.MEDIUM;
        this.reminded = false;
    }

    // Constructor for creating NEW tasks programmatically
    // Room can ignore this if you add @Ignore, or it might try to use it if fields match
    // For safety with Room, if this isn't intended for Room, add @Ignore
    // @androidx.room.Ignore
    public Task(String title, String description, LocalDate dueDate) {
        this(); // Call no-arg constructor to set defaults
        this.id = UUID.randomUUID().toString(); // Then generate a new ID
        this.title = Objects.requireNonNull(title, "Title cannot be null");
        this.description = description != null ? description : "";
        this.creationTimestamp = LocalDateTime.now();
        this.dueDate = dueDate;
        // status, priority, reminded are already set by no-arg constructor
    }

    // Constructor for LOADING from other sources (like your old H2 repo)
    // Room can ignore this if you add @Ignore
    // @androidx.room.Ignore
    public Task(String id, String title, String description, LocalDateTime creationTimestamp,
                LocalDate dueDate, LocalDateTime reminderDateTime,
                Priority priority, Status status, boolean reminded, String category) {
        this.id = id;
        this.title = Objects.requireNonNull(title, "Title cannot be null");
        this.description = description != null ? description : "";
        this.creationTimestamp = creationTimestamp;
        this.dueDate = dueDate;
        this.reminderDateTime = reminderDateTime;
        this.priority = (priority != null) ? priority : Priority.MEDIUM;
        this.status = (status != null) ? status : Status.PENDING;
        this.reminded = reminded;
        this.category = category;
    }

    // Getters
    @androidx.annotation.NonNull
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public LocalDateTime getCreationTimestamp() { return creationTimestamp; } // RENAMED
    public LocalDate getDueDate() { return dueDate; }
    public LocalDateTime getReminderDateTime() { return reminderDateTime; }
    public Priority getPriority() { return priority; }
    public Status getStatus() { return status; }
    public boolean isReminded() { return reminded; }
    public String getCategory() { return category; }

    // Setters (Room needs these if fields are private)
    public void setId(@androidx.annotation.NonNull String id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setCreationTimestamp(LocalDateTime creationTimestamp) { this.creationTimestamp = creationTimestamp; } // RENAMED
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public void setReminderDateTime(LocalDateTime reminderDateTime) { this.reminderDateTime = reminderDateTime; }
    public void setPriority(Priority priority) { this.priority = priority; }
    public void setStatus(Status status) { this.status = status; }
    public void setReminded(boolean reminded) { this.reminded = reminded; }
    public void setCategory(String category) { this.category = category; }
}
