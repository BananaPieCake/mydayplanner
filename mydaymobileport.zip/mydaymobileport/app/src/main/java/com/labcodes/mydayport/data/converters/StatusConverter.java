package com.labcodes.mydayport.data.converters;

import androidx.room.TypeConverter;
import com.labcodes.mydayport.model.Task;

public class StatusConverter {
    @TypeConverter
    public static String fromStatus(Task.Status status) {
        return status == null ? null : status.name();
    }

    @TypeConverter
    public static Task.Status toStatus(String statusName) {
        return statusName == null ? null : Task.Status.valueOf(statusName);
    }
}