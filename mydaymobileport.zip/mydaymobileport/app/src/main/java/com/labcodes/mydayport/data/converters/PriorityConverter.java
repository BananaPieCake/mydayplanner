package com.labcodes.mydayport.data.converters;

import androidx.room.TypeConverter;
import com.labcodes.mydayport.model.Task;

public class PriorityConverter {
    @TypeConverter
    public static String fromPriority(Task.Priority priority) {
        return priority == null ? null : priority.name();
    }

    @TypeConverter
    public static Task.Priority toPriority(String priorityName) {
        return priorityName == null ? null : Task.Priority.valueOf(priorityName);
    }
}