package com.labcodes.mydayport.repositories;

import java.util.List;
import java.util.Optional;
import com.labcodes.mydayport.model.Task;
import java.time.LocalDate;
import java.util.Map;

/**
 *
 * @author Miguel Pogi
 */
public interface TaskRepository {

    Task save(Task task);
    Map<LocalDate, Long> getTasksCompletedPerDay(LocalDate startDate, LocalDate endDate);
    Optional<Task> findById(String idTask);

    List<Task> findAll();
    List<Task> findActiveTasks();
    List<Task> searchActiveTasks(String searchTerm);
    List<Task> getActiveTasksByDate(LocalDate date);
    Map<Task.Priority, Long> getTaskCountByPriority();

    List<Task> findTasksByDate(LocalDate date, boolean activeOnly, Task.Priority priorityFilter, Task.Status statusFilter, String sortOrder);
    List<Task> findTasksByDateRange(LocalDate startDate, LocalDate endDate, boolean activeOnly, Task.Priority priorityFilter, Task.Status statusFilter, String sortOrder);
    List<Task> findTasksGeneral(Task.Status statusFilter, Task.Priority priorityFilter, String sortOrder);


    // Deletes a task by its unique ID. Returns true if deleted, false otherwise.
    boolean deleteById(String id);

    // implement finding by tags on services u can add that.
    // List<Task> findByDueDate(LocalDate date);
    // List<Task> findByStatus(Task.Status status);
    // List<Task> findByTag(String tag);

}
