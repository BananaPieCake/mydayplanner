package com.labcodes.mydayport.view.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.labcodes.mydayport.MainActivity;
import com.labcodes.mydayport.R;
import com.labcodes.mydayport.model.Task;
import com.labcodes.mydayport.services.TaskService;
import com.labcodes.mydayport.view.AddTaskDialogFragment;
import com.labcodes.mydayport.view.TaskAdapter;

import java.time.DayOfWeek; // Import DayOfWeek
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters; // Import TemporalAdjusters
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors; // For Stream filtering

public class WeekFragment extends Fragment implements
        AddTaskDialogFragment.AddTaskDialogListener,
        TaskAdapter.OnTaskClickListener,
        TaskAdapter.OnTaskOptionsClickListener,
        TaskAdapter.OnTaskCheckboxClickListener {

    // UI Components from fragment_today.xml
    private RecyclerView recyclerViewTasks;
    private FloatingActionButton fabAddTaskFragment;
    private TextView tvCurrentDateFragment;
    private TextView tvTaskCountFragment;

    // Contextual Action Bar UI Components
    private View contextualActionBar;
    private TextView tvSelectedCountContextual;
    private ImageButton btnCloseContextualAction;
    private ImageButton btnSelectAllContextual;
    private ImageButton btnCompleteSelectedContextual;
    private ImageButton btnDeleteSelectedContextual;



    // Data and Adapters
    private TaskAdapter taskAdapter;
    private TaskService taskService;
    private List<Task> selectedTasksList = new ArrayList<>();

    public WeekFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() instanceof MainActivity) {
            taskService = ((MainActivity) getActivity()).getTaskService();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_today, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize standard views
        recyclerViewTasks = view.findViewById(R.id.fragment_today_recyclerview_tasks);
        fabAddTaskFragment = view.findViewById(R.id.fragment_today_fab_add_task);
        tvCurrentDateFragment = view.findViewById(R.id.fragment_today_tv_date);
        tvTaskCountFragment = view.findViewById(R.id.fragment_today_tv_task_count);

        // Initialize Contextual Action Bar views
        contextualActionBar = view.findViewById(R.id.contextual_action_bar_layout);
        if (contextualActionBar != null) {
            tvSelectedCountContextual = contextualActionBar.findViewById(R.id.tv_selected_count_contextual);
            btnCloseContextualAction = contextualActionBar.findViewById(R.id.btn_close_contextual_action);
            btnSelectAllContextual = contextualActionBar.findViewById(R.id.btn_select_all_contextual);
            btnCompleteSelectedContextual = contextualActionBar.findViewById(R.id.btn_complete_selected_contextual);
            btnDeleteSelectedContextual = contextualActionBar.findViewById(R.id.btn_delete_selected_contextual);

            // Set listeners for contextual action bar buttons
            if (btnCloseContextualAction != null) btnCloseContextualAction.setOnClickListener(v -> clearSelectionMode());
            if (btnSelectAllContextual != null) btnSelectAllContextual.setOnClickListener(v -> handleSelectAllTasks());
            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setOnClickListener(v -> handleCompleteSelectedTasks());
            if (btnDeleteSelectedContextual != null) btnDeleteSelectedContextual.setOnClickListener(v -> handleDeleteSelectedTasks());
        } else {
            System.err.println("WeekFragment: Contextual Action Bar layout (e.g., R.id.today_contextual_action_bar) not found!");
        }

        setupRecyclerView();
        setupFab();
        updateDateHeaderInFragment();
        loadTasksForFragment();
        updateContextualActionBar(); // Set initial state (should be hidden)
    }

    private void setupRecyclerView() {
        if (recyclerViewTasks == null) return;
        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(getContext()));
        taskAdapter = new TaskAdapter(this, this, this); // Pass 'this' for listeners
        recyclerViewTasks.setAdapter(taskAdapter);
    }

    private void setupFab() {
        if (fabAddTaskFragment == null) return;
        fabAddTaskFragment.setOnClickListener(v -> {
            AddTaskDialogFragment dialogFragment = AddTaskDialogFragment.newInstance(null);
            dialogFragment.show(getParentFragmentManager(), "AddTaskFromTodayFragment");
        });
    }

    private void updateDateHeaderInFragment() {
        if (tvCurrentDateFragment == null) return;
        LocalDate today = LocalDate.now();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        tvCurrentDateFragment.setText(today.format(dateFormatter));
    }

    public void loadTasksForFragment() {
        if (taskService == null || taskAdapter == null || tvTaskCountFragment == null) {
            System.err.println("WeekFragment: Cannot load tasks - service, adapter, or countLabel is null.");
            return;
        }

        final LocalDate today = LocalDate.now();
        final LocalDate startOfWeek = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        final LocalDate endOfWeek = today.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));

        System.out.println("WeekFragment: Loading tasks for week: " + startOfWeek + " to " + endOfWeek); // DEBUG

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {

            List<Task> allActiveTasks = taskService.getActiveTasks();
            final List<Task> tasksForThisWeek;

            if (allActiveTasks != null) {

                tasksForThisWeek = allActiveTasks.stream()
                        .filter(task -> {
                            LocalDate taskDueDate = task.getDueDate();
                            if (taskDueDate == null) {
                                return false;
                            }

                            boolean isAfterOrOnStart = !taskDueDate.isBefore(startOfWeek);
                            boolean isBeforeOrOnEnd = !taskDueDate.isAfter(endOfWeek);
                            return isAfterOrOnStart && isBeforeOrOnEnd;
                        })
                        .collect(Collectors.toList());
                System.out.println("WeekFragment: Filtered " + allActiveTasks.size() + " active tasks down to " + tasksForThisWeek.size() + " for the week."); // DEBUG
            } else {
                tasksForThisWeek = new ArrayList<>();
                System.out.println("WeekFragment: No active tasks returned from service.");
            }

            handler.post(() -> {
                if (taskAdapter != null) {
                    taskAdapter.submitList(tasksForThisWeek);
                    taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
                }
                if (tvTaskCountFragment != null) {
                    tvTaskCountFragment.setText("You have " + tasksForThisWeek.size() + " task(s) this week.");
                }
            });
        });
    }

    // --- Listener for AddTaskDialogFragment ---
    @Override
    public void onTaskAdded(Task newTask) {
        loadTasksForFragment();
    }

    // --- TaskAdapter Listeners ---
    @Override
    public void onTaskClick(Task task) {
        Toast.makeText(getContext(), "Clicked: " + task.getTitle(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onTaskOptionsClick(Task task, View anchorView) {
        PopupMenu popup = new PopupMenu(requireContext(), anchorView);
        popup.getMenuInflater().inflate(R.menu.task_item_options_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> { /* ... your edit/delete logic ... */ return true;});
        popup.show();
    }

    @Override
    public void onTaskSelectionChanged(Task task, boolean isSelected) {
        if (isSelected) {
            if (!selectedTasksList.contains(task)) selectedTasksList.add(task);
        } else {
            selectedTasksList.remove(task);
        }
        if (taskAdapter != null) {
            taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
        }
        updateContextualActionBar();
    }


    // --- Contextual Action Bar Methods ---
    private void updateContextualActionBar() {
        if (contextualActionBar == null) return;

        boolean hasSelection = !selectedTasksList.isEmpty();
        contextualActionBar.setVisibility(hasSelection ? View.VISIBLE : View.GONE);

        if (hasSelection) {
            if (tvSelectedCountContextual != null) {
                tvSelectedCountContextual.setText(selectedTasksList.size() + " selected");
            }
            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setEnabled(true);
            if (btnDeleteSelectedContextual != null) btnDeleteSelectedContextual.setEnabled(true);
            if (btnCloseContextualAction != null) btnCloseContextualAction.setEnabled(true);

            if (btnSelectAllContextual != null) {
                List<Task> currentDisplayedTasks = taskAdapter.getCurrentList();
                int totalActiveDisplayableTasks = 0;
                if (currentDisplayedTasks != null) {
                    for (Task t : currentDisplayedTasks) {
                        if (t.getStatus() != Task.Status.COMPLETED) totalActiveDisplayableTasks++;
                    }
                }
                btnSelectAllContextual.setEnabled(selectedTasksList.size() < totalActiveDisplayableTasks);
            }
        } else {

            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setEnabled(false);
            if (btnDeleteSelectedContextual != null) btnDeleteSelectedContextual.setEnabled(false);
            if (btnSelectAllContextual != null) btnSelectAllContextual.setEnabled(true);
        }
    }

    private void clearSelectionMode() {
        selectedTasksList.clear();
        if (taskAdapter != null) {
            taskAdapter.clearSelectedTaskIdsForBulk();
        }
        updateContextualActionBar();
    }

    private void handleSelectAllTasks() {
        selectedTasksList.clear();
        List<Task> currentDisplayedTasks = taskAdapter.getCurrentList();
        if (currentDisplayedTasks != null) {
            for (Task task : currentDisplayedTasks) {
                if (task.getStatus() != Task.Status.COMPLETED) {
                    selectedTasksList.add(task);
                }
            }
        }
        if (taskAdapter != null) {
            taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
        }
        updateContextualActionBar();
    }

    private void handleCompleteSelectedTasks() {
        if (selectedTasksList.isEmpty()) return;
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());
        executor.execute(() -> {
            for (Task task : new ArrayList<>(selectedTasksList)) {
                task.setStatus(Task.Status.COMPLETED);
                task.setReminded(false);
                taskService.save(task);
            }
            handler.post(() -> {
                selectedTasksList.clear();
                if (taskAdapter != null) taskAdapter.clearSelectedTaskIdsForBulk(); // Clear adapter's selection
                loadTasksForFragment();     // Reload data (will filter out completed)
                updateContextualActionBar(); // Hide bar
                Toast.makeText(getContext(), "Tasks marked complete", Toast.LENGTH_SHORT).show();
            });
        });
    }

    private void handleDeleteSelectedTasks() {
        if (selectedTasksList.isEmpty()) return;
        new AlertDialog.Builder(requireContext())
                .setTitle("Confirm Delete")
                .setMessage("Delete " + selectedTasksList.size() + " selected task(s)?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());
                    executor.execute(() -> {
                        for (Task task : new ArrayList<>(selectedTasksList)) {
                            taskService.deleteTask(task.getId());
                        }
                        handler.post(() -> {
                            selectedTasksList.clear();
                            if (taskAdapter != null) taskAdapter.clearSelectedTaskIdsForBulk();
                            loadTasksForFragment();
                            updateContextualActionBar();
                            Toast.makeText(getContext(), "Tasks deleted", Toast.LENGTH_SHORT).show();
                        });
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }


    private void confirmAndDeleteTaskInFragment(Task task) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Confirm Delete")
                .setMessage("Delete task: '" + task.getTitle() + "'?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());
                    executor.execute(() -> {
                        taskService.deleteTask(task.getId());
                        handler.post(()-> {

                            selectedTasksList.remove(task);
                            if (taskAdapter != null) taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList); // Update adapter
                            loadTasksForFragment(); // Refresh the list
                            updateContextualActionBar(); // Update bar state
                            Toast.makeText(getContext(), "Task deleted", Toast.LENGTH_SHORT).show();
                        });
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}

