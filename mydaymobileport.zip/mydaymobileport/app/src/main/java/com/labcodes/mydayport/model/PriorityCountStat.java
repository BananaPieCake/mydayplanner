package com.labcodes.mydayport.model;
import androidx.room.ColumnInfo;


public class PriorityCountStat {

    @ColumnInfo(name = "priority")
    public Task.Priority priority;

    @ColumnInfo(name = "count")
    public int count;

    public PriorityCountStat() {
    }

    public PriorityCountStat(Task.Priority priority, int count) {
        this.priority = priority;
        this.count = count;
    }

    @Override
    public String toString() {
        return "PriorityCountStat{" +
                "priority=" + (priority != null ? priority.name() : "NULL") +
                ", count=" + count +
                '}';
    }
}