package com.labcodes.mydayport.model;


import androidx.room.ColumnInfo;
import androidx.room.Entity;

import java.time.LocalDate;


public class DailyCompletionStat {
    @ColumnInfo(name = "due_date") // Matches the 'due_date' column from your SQL
    public LocalDate dueDate;

    @ColumnInfo(name = "count")    // Matches the 'COUNT(*) as count' alias from your SQL
    public int count;

    // Room can use a no-arg constructor or one that matches the fields for POJOs
    public DailyCompletionStat() {}

    // Optional: Constructor for convenience if you create these manually elsewhere
    public DailyCompletionStat(LocalDate dueDate, int count) {
        this.dueDate = dueDate;
        this.count = count;
    }

}
