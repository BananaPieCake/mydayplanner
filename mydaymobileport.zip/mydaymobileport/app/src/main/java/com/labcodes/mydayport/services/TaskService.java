package com.labcodes.mydayport.services;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.Map;

import com.labcodes.mydayport.model.Task;
import com.labcodes.mydayport.repositories.TaskRepository;
import java.util.LinkedHashMap;

/**
 *
 * @author Miguel Pogi
 */
public class TaskService {

    private final TaskRepository taskRepository; // Depends on the interface, not implementation!

    // Constructor Injection: Provide the repository when creating the service
    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = Objects.requireNonNull(taskRepository, "TaskRepository cannot be null");
    }

    public Map<Task.Priority, Long> getTaskCountByPriority() {
        return taskRepository.getTaskCountByPriority();
    }

    // filter cate
    public List<Task> getTasksForTodayFilteredAndSorted(LocalDate date, Task.Priority priorityFilter, String sortOrder) {
        return taskRepository.findTasksByDate(date, true, priorityFilter, null, sortOrder); // true for active only
    }

    public List<Task> getTasksForWeekFilteredAndSorted(LocalDate startDate, LocalDate endDate, Task.Priority priorityFilter, String sortOrder) {
        return taskRepository.findTasksByDateRange(startDate, endDate, true, priorityFilter, null, sortOrder); // true for active
    }

    public List<Task> getAllTasksFilteredAndSorted(Task.Status statusFilter, Task.Priority priorityFilter, String sortOrder) {
        // If statusFilter is null, repository should fetch all statuses.
        // If statusFilter is COMPLETED, repository should fetch only completed.
        // If statusFilter is PENDING/IN_PROGRESS, repository should fetch those.
        return taskRepository.findTasksGeneral(statusFilter, priorityFilter, sortOrder);
    }
    // end of it



    // --- CRUD Operations ---

    public Task createTask(String title, String description, LocalDate dueDate) {
        // Add validation or default logic here if needed
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Task title cannot be empty.");
        }
        Task newTask = new Task(title, description, dueDate);
        return taskRepository.save(newTask);
    }

    // Update or Insert?
    public Task save(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }
        return taskRepository.save(task);
    }

    public Optional<Task> getTaskById(String id) {
        return taskRepository.findById(id);
    }

    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    public boolean deleteTask(String id) {
        // You could add logic here: check if task exists first, etc.
        return taskRepository.deleteById(id);
    }

    public Optional<Task> updateTask(String id, String newTitle, String newDescription, LocalDate newDueDate, Task.Priority newPriority, Task.Status newStatus) {
        Optional<Task> existingTaskOpt = taskRepository.findById(id);
        if (existingTaskOpt.isPresent()) {
            Task taskToUpdate = existingTaskOpt.get();
            // Update fields (add null checks or specific logic as needed)
            if (newTitle != null && !newTitle.trim().isEmpty()) {
                taskToUpdate.setTitle(newTitle);
            }
            if (newDescription != null) {
                taskToUpdate.setDescription(newDescription);
            }
            if (newDueDate != null) {
                taskToUpdate.setDueDate(newDueDate);
            }
            if (newPriority != null) {
                taskToUpdate.setPriority(newPriority);
            }
            if (newStatus != null) {
                taskToUpdate.setStatus(newStatus);
            }
            // etc. for other fields like tags, reminder...

            taskRepository.save(taskToUpdate); // Save the updated task
            return Optional.of(taskToUpdate);
        }
        return Optional.empty(); // Task not found
    }

    public Optional<Task> markTaskStatus(String id, Task.Status status) {
        Optional<Task> taskOpt = taskRepository.findById(id);
        if (taskOpt.isPresent()) {
            Task task = taskOpt.get();
            task.setStatus(status);
            taskRepository.save(task);
            return Optional.of(task);
        }
        return Optional.empty();
    }

    public List<Task> getActiveTasks() {
        return taskRepository.findActiveTasks();
    }

    public List<Task> searchActiveTasks(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getActiveTasks(); // Or an empty list
        }
        return taskRepository.searchActiveTasks(searchTerm.toLowerCase()); // Pass lowercase for case-insensitive
    }

    public List<Task> getActiveTasksByDate(LocalDate date) {
        return taskRepository.findActiveTasks().stream()
                .filter(task -> task.getDueDate() != null && task.getDueDate().isEqual(date))
                .collect(Collectors.toList());
    }


    // --- Feature-Specific Methods --- //

    public List<Task> getTasksForToday() {
        LocalDate today = LocalDate.now();
        return (List<Task>) taskRepository.findAll().stream()
                .filter(task -> today.equals(task.getDueDate()))
                .filter(task -> task.getStatus() != Task.Status.COMPLETED)
                .collect(Collectors.toList());
    }

    public List<Task> getTasksByPriority(Task.Priority priority) {
        return taskRepository.findAll().stream()
                .filter(task -> priority.equals(task.getPriority()))
                .collect(Collectors.toList());
    }

    public List<Task> getTasksByStatus(Task.Status status) {
        return taskRepository.findAll().stream()
                .filter(task -> status.equals(task.getStatus()))
                .collect(Collectors.toList());
    }

    // --- for jfreechart --- //
    public Map<LocalDate, Long> getTasksCompletedPerDayForLastNDays(int days) {
        if (days <= 0) {
            return new LinkedHashMap<>(); // Return empty map for invalid input
        }
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusDays(days - 1); // e.g., for 7 days, today back to 6 days ago
        return taskRepository.getTasksCompletedPerDay(startDate, endDate);
    }
}
