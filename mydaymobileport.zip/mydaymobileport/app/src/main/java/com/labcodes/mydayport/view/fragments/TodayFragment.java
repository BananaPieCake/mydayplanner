package com.labcodes.mydayport.view.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast; // For Toast messages

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.PopupMenu; // For options menu

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.labcodes.mydayport.MainActivity;
import com.labcodes.mydayport.R;
import com.labcodes.mydayport.model.Task;
import com.labcodes.mydayport.services.TaskService;
import com.labcodes.mydayport.view.AddTaskDialogFragment;
import com.labcodes.mydayport.view.TaskAdapter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TodayFragment extends Fragment implements AddTaskDialogFragment.AddTaskDialogListener,
        TaskAdapter.OnTaskClickListener, TaskAdapter.OnTaskOptionsClickListener, TaskAdapter.OnTaskCheckboxClickListener {

    private RecyclerView recyclerViewTasks;
    private FloatingActionButton fabAddTaskFragment;
    private TextView tvCurrentDateFragment;
    private TextView tvTaskCountFragment;
    private TaskAdapter taskAdapter;
    private TaskService taskService;
    private List<Task> selectedTasksList = new ArrayList<>();
    private View contextualActionBar;
    private TextView tvSelectedCountContextual;
    private ImageButton btnSelectAllContextual, btnCompleteSelectedContextual,
            btnDeleteSelectedContextual, btnCloseContextualAction;

    private Task.Priority currentPriorityFilter = null;
    private Task.Status currentStatusFilter = null;
    private String currentSortOrder = "DEFAULT_DUE_DATE_ASC";

    public TodayFragment() {
        // Required empty public constructor
    }

    private void updateContextualActionBar() {
        if (contextualActionBar == null) {
            System.err.println("Fragment: contextualActionBar VIEW IS NULL!"); // DEBUG
            return;
        }
        if (tvSelectedCountContextual == null) { // Check other critical views too
            System.err.println("Fragment: tvSelectedCountContextual VIEW IS NULL!");
        }


        boolean hasSelection = !selectedTasksList.isEmpty();
        System.out.println("Fragment: updateContextualActionBar - hasSelection: " + hasSelection); // DEBUG

        contextualActionBar.setVisibility(hasSelection ? View.VISIBLE : View.GONE);

        if (hasSelection) {
            if (tvSelectedCountContextual != null) {
                tvSelectedCountContextual.setText(selectedTasksList.size() + " selected");
            }
            // Enable/disable action buttons
            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setEnabled(true);
            if (btnDeleteSelectedContextual != null) btnDeleteSelectedContextual.setEnabled(true);
            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setEnabled(true);
            if (btnCloseContextualAction != null) btnCloseContextualAction.setEnabled(true);
        } else {
            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setEnabled(false);
            if (btnDeleteSelectedContextual != null) btnDeleteSelectedContextual.setEnabled(false);
            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setEnabled(false);
            if (btnCloseContextualAction != null) btnCloseContextualAction.setEnabled(false);
        }

        // Revalidate parent if necessary (ConstraintLayout usually handles this well)
        View parentView = (View) contextualActionBar.getParent();
        if (parentView != null) {
            parentView.requestLayout(); // Force parent to re-layout its children
            parentView.invalidate();    // Force parent to redraw
        }
        System.out.println("Fragment: contextualActionBar visibility set to: " + (hasSelection ? "VISIBLE" : "GONE")); // DEBUG
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Initialize TaskService (get from Activity)
        if (getActivity() instanceof MainActivity) {
            taskService = ((MainActivity) getActivity()).getTaskService();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_today, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize views from the fragment's layout
        contextualActionBar = view.findViewById(R.id.contextual_action_bar_layout);
        recyclerViewTasks = view.findViewById(R.id.fragment_today_recyclerview_tasks);
        fabAddTaskFragment = view.findViewById(R.id.fragment_today_fab_add_task);
        tvCurrentDateFragment = view.findViewById(R.id.fragment_today_tv_date);
        tvTaskCountFragment = view.findViewById(R.id.fragment_today_tv_task_count);


        // initialize inside the contextualactionbar
        if (contextualActionBar != null) {
            tvSelectedCountContextual = contextualActionBar.findViewById(R.id.tv_selected_count_contextual);
            btnSelectAllContextual = contextualActionBar.findViewById(R.id.btn_select_all_contextual);
            btnCompleteSelectedContextual = contextualActionBar.findViewById(R.id.btn_complete_selected_contextual);
            btnDeleteSelectedContextual = contextualActionBar.findViewById(R.id.btn_delete_selected_contextual);
            btnCloseContextualAction = contextualActionBar.findViewById(R.id.btn_close_contextual_action);

            // Set listeners for these buttons
            if (btnCloseContextualAction != null) btnCloseContextualAction.setOnClickListener(v -> clearSelectionMode());
            if (btnSelectAllContextual != null) btnSelectAllContextual.setOnClickListener(v -> handleSelectAllTasks());
            if (btnCompleteSelectedContextual != null) { btnCompleteSelectedContextual.setOnClickListener(v -> handleCompleteSelectedTasks());}
            if (btnDeleteSelectedContextual != null) { btnDeleteSelectedContextual.setOnClickListener(v -> handleDeleteSelectedTasks());}


        } else {
            // This else block will be hit if contextualActionBar itself is null
            System.err.println("Fragment onViewCreated: contextual_action_bar_layout (or your ID) NOT FOUND in fragment's layout!");
        }

        setupRecyclerView();
        setupFab();
        updateActiveFilterDisplay();
        updateContextualActionBar();
        updateDateHeaderInFragment();
        loadTasksForFragment();
    }

    private void setupRecyclerView() {
        if (recyclerViewTasks == null) return;
        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(getContext()));
        taskAdapter = new TaskAdapter(this, this, this); // Pass 'this' as listeners
        recyclerViewTasks.setAdapter(taskAdapter);
    }

    private void setupFab() {
        if (fabAddTaskFragment == null) return;
        fabAddTaskFragment.setOnClickListener(v -> {
            AddTaskDialogFragment dialogFragment = AddTaskDialogFragment.newInstance(null);
            // Listener is set if MainActivity makes TodayFragment implement it,
            // or if DialogFragment gets listener from Activity directly
            dialogFragment.show(getParentFragmentManager(), "AddTaskFromToday");
        });
    }


    private void updateDateHeaderInFragment() {
        if (tvCurrentDateFragment == null) return;
        LocalDate today = LocalDate.now();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
        tvCurrentDateFragment.setText(today.format(dateFormatter));
    }

    public void loadTasksForFragment() {
        if (taskService == null || taskAdapter == null || tvTaskCountFragment == null) {
            System.err.println("TodayFragment: Cannot load tasks - service, adapter, or countLabel is null.");
            return;
        }

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            final List<Task> tasksToDisplay = taskService.getTasksForTodayFilteredAndSorted(
                    LocalDate.now(),
                    this.currentPriorityFilter,
                    this.currentSortOrder
            );

            handler.post(() -> {
                if (taskAdapter != null) {
                    taskAdapter.submitList(tasksToDisplay);
                    taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
                }
                if (tvTaskCountFragment != null) {
                    tvTaskCountFragment.setText("You have " + (tasksToDisplay != null ? tasksToDisplay.size() : 0) + " task(s) today.");
                }
                System.out.println("TodayFragment: Tasks loaded. Count: " + (tasksToDisplay != null ? tasksToDisplay.size() : 0));
            });
        });
    }

    // Implementation of AddTaskDialogFragment.AddTaskDialogListener
    @Override
    public void onTaskAdded(Task newTask) {
        System.out.println("TodayFragment: New task added - " + newTask.getTitle());
        loadTasksForFragment();
    }

    // Implementation of TaskAdapter Listeners
    @Override
    public void onTaskClick(Task task) {
        System.out.println("TodayFragment: Task clicked: " + task.getTitle());
        Toast.makeText(getContext(), "Clicked: " + task.getTitle(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onTaskOptionsClick(Task task, View anchorView) {
        System.out.println("TodayFragment: Options for: " + task.getTitle());
        PopupMenu popup = new PopupMenu(requireContext(), anchorView);
        popup.getMenuInflater().inflate(R.menu.task_item_options_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.action_edit_task) {
                AddTaskDialogFragment editDialog = AddTaskDialogFragment.newInstance(task);
                editDialog.show(getParentFragmentManager(), "EditTaskDialogFromToday");
                return true;
            } else if (itemId == R.id.action_delete_task) {
                confirmAndDeleteTaskInFragment(task);
                return true;
            }
            return false;
        });
        popup.show();
    }

    @Override
    public void onTaskSelectionChanged(Task task, boolean isSelected) {
        if (isSelected) {
            if (!selectedTasksList.contains(task)) selectedTasksList.add(task);
        } else {
            selectedTasksList.remove(task);
        }
        if (taskAdapter != null) {
            taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
        }
        System.out.println("Fragment: onTaskSelectionChanged - Calling updateContextualActionBar. Selected count: " + selectedTasksList.size()); // DEBUG
        updateContextualActionBar();
    }

    // for filter
    public void showFilterOptions() {

        cyclePriorityFilter();
    }

    private void cyclePriorityFilter() {
        if (currentPriorityFilter == null) {
            currentPriorityFilter = Task.Priority.HIGH;
        } else if (currentPriorityFilter == Task.Priority.HIGH) {
            currentPriorityFilter = Task.Priority.MEDIUM;
        } else if (currentPriorityFilter == Task.Priority.MEDIUM) {
            currentPriorityFilter = Task.Priority.LOW;
        } else if (currentPriorityFilter == Task.Priority.LOW) {
            currentPriorityFilter = null;
        }

        updateActiveFilterDisplay();
        loadTasksForFragment();
    }

    private void updateActiveFilterDisplay() {
        String filterMessage;
        if (currentPriorityFilter != null) {
            filterMessage = "Filtered by Priority: " + currentPriorityFilter.name();
        } else {
            filterMessage = "Filter: All Priorities";
        }
        if (getContext() != null) { // Check context availability
            Toast.makeText(getContext(), filterMessage, Toast.LENGTH_SHORT).show();
        }
    }

    // contextual thingy for selection
    private void clearSelectionMode() {
        selectedTasksList.clear();
        taskAdapter.clearSelectedTaskIdsForBulk();
        updateContextualActionBar();
    }

    private void handleSelectAllTasks() {
        selectedTasksList.clear();
        List<Task> currentDisplayedTasks = taskAdapter.getCurrentList(); // From ListAdapter
        if (currentDisplayedTasks != null) {
            for(Task task : currentDisplayedTasks) {
                if(task.getStatus() != Task.Status.COMPLETED) {
                    selectedTasksList.add(task);
                }
            }
        }
        taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
        updateContextualActionBar();
    }

    private void handleDeleteSelectedTasks() {
        if (selectedTasksList.isEmpty()) {
            Toast.makeText(getContext(), "No tasks selected to delete.", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(requireContext())
                .setTitle("Confirm Delete")
                .setMessage("Are you sure you want to delete " + selectedTasksList.size() + " selected task(s)?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    System.out.println("Fragment: Deleting " + selectedTasksList.size() + " tasks...");
                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());

                    executor.execute(() -> {

                        for (Task taskToDelete : new ArrayList<>(selectedTasksList)) {
                            taskService.deleteTask(taskToDelete.getId());
                        }
                        handler.post(() -> {
                            selectedTasksList.clear();    // Clear the selection
                            loadTasksForFragment();       // Refresh the main list
                            updateContextualActionBar();  // Hide the contextual action bar
                            Toast.makeText(getContext(), "Selected tasks deleted", Toast.LENGTH_SHORT).show();
                        });
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void handleCompleteSelectedTasks() {
        if (selectedTasksList.isEmpty()) return;
        System.out.println("Fragment: Completing " + selectedTasksList.size() + " tasks...");
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());
        executor.execute(() -> {
            for (Task task : new ArrayList<>(selectedTasksList)) {
                task.setStatus(Task.Status.COMPLETED);
                task.setReminded(false);
                taskService.save(task);
            }
            handler.post(() -> {
                selectedTasksList.clear();
                loadTasksForFragment();
                updateContextualActionBar();
                Toast.makeText(getContext(), "Tasks marked complete", Toast.LENGTH_SHORT).show();
            });
        });
    }


    private void confirmAndDeleteTaskInFragment(Task task) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Confirm Delete")
                .setMessage("Delete task: '" + task.getTitle() + "'?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    executor.execute(() -> {
                        taskService.deleteTask(task.getId());
                        new Handler(Looper.getMainLooper()).post(this::loadTasksForFragment);
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
