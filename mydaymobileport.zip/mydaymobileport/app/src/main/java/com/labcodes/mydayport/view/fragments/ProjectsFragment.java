package com.labcodes.mydayport.view.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.labcodes.mydayport.MainActivity;
import com.labcodes.mydayport.R;
import com.labcodes.mydayport.model.Task;
import com.labcodes.mydayport.services.TaskService;
import com.labcodes.mydayport.view.AddTaskDialogFragment;
import com.labcodes.mydayport.view.TaskAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProjectsFragment extends Fragment implements
        AddTaskDialogFragment.AddTaskDialogListener,
        TaskAdapter.OnTaskClickListener,
        TaskAdapter.OnTaskOptionsClickListener,
        TaskAdapter.OnTaskCheckboxClickListener {

    private RecyclerView recyclerViewTasks;
    private TextView tvProjectsTitle;
    private TextView tvProjectsTaskCount;
    private FloatingActionButton fabAddProjectTask;

    // Contextual Action Bar UI Components
    private View contextualActionBar;
    private TextView tvSelectedCountContextual;
    private ImageButton btnCloseContextualAction;
    private ImageButton btnSelectAllContextual;
    private ImageButton btnCompleteSelectedContextual;
    private ImageButton btnDeleteSelectedContextual;

    private TaskAdapter taskAdapter;
    private TaskService taskService;
    private List<Task> selectedTasksList = new ArrayList<>();

    public ProjectsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() instanceof MainActivity) {
            taskService = ((MainActivity) getActivity()).getTaskService();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_project, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerViewTasks = view.findViewById(R.id.fragment_projects_recyclerview_tasks);
        tvProjectsTitle = view.findViewById(R.id.fragment_projects_tv_title);
        tvProjectsTaskCount = view.findViewById(R.id.fragment_projects_tv_task_count);
        fabAddProjectTask = view.findViewById(R.id.fragment_projects_fab_add_task);

        // Initialize Contextual Action Bar views
        contextualActionBar = view.findViewById(R.id.contextual_action_bar_layout);
        if (contextualActionBar != null) {
            tvSelectedCountContextual = contextualActionBar.findViewById(R.id.tv_selected_count_contextual);
            btnCloseContextualAction = contextualActionBar.findViewById(R.id.btn_close_contextual_action);
            btnSelectAllContextual = contextualActionBar.findViewById(R.id.btn_select_all_contextual);
            btnCompleteSelectedContextual = contextualActionBar.findViewById(R.id.btn_complete_selected_contextual);
            btnDeleteSelectedContextual = contextualActionBar.findViewById(R.id.btn_delete_selected_contextual);

            // Set listeners
            if (btnCloseContextualAction != null) btnCloseContextualAction.setOnClickListener(v -> clearSelectionMode());
            if (btnSelectAllContextual != null) btnSelectAllContextual.setOnClickListener(v -> handleSelectAllTasks());
            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setOnClickListener(v -> handleCompleteSelectedTasks());
            if (btnDeleteSelectedContextual != null) btnDeleteSelectedContextual.setOnClickListener(v -> handleDeleteSelectedTasks());
        }

        setupRecyclerView();
        setupFab();
        loadTasksForFragment();
        updateContextualActionBar();
    }

    private void setupRecyclerView() {
        if (recyclerViewTasks == null) return;
        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(getContext()));
        taskAdapter = new TaskAdapter(this, this, this);
        recyclerViewTasks.setAdapter(taskAdapter);
    }

    private void setupFab() {
        if (fabAddProjectTask == null) return;
        fabAddProjectTask.setOnClickListener(v -> {
            AddTaskDialogFragment dialogFragment = AddTaskDialogFragment.newInstance(null);
            dialogFragment.show(getParentFragmentManager(), "AddTaskFromTodayFragment");
        });
    }

    public void loadTasksForFragment() {
        if (taskService == null || taskAdapter == null || tvProjectsTaskCount == null) return;

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            // For "Projects" or "All Tasks", you likely want everything including completed
            final List<Task> allTasks = taskService.getAllTasks();
            // TODO: Later, if tasks have a "project" attribute or tag, filter here:
            // final List<Task> projectTasks = allTasks.stream()
            //     .filter(task -> "SpecificProjectName".equals(task.getProjectTag()))
            //     .collect(Collectors.toList());
            // For now, displaying ALL tasks (active and completed)

            handler.post(() -> {
                taskAdapter.submitList(allTasks); // Pass the list of all tasks
                if (taskAdapter != null) taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
                tvProjectsTaskCount.setText(allTasks.size() + " total task(s).");
                if (tvProjectsTitle != null) tvProjectsTitle.setText("All Tasks"); // Or specific project name
            });
        });
    }

    // --- Listener for AddTaskDialogFragment ---
    @Override
    public void onTaskAdded(Task newTask) {
        loadTasksForFragment();
    }

    // --- TaskAdapter Listeners  ---
    @Override
    public void onTaskClick(Task task) {
        Toast.makeText(getContext(), "Projects - Clicked: " + task.getTitle(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onTaskOptionsClick(Task task, View anchorView) {
        // Same logic as other fragments for showing PopupMenu (Edit, Delete)
        PopupMenu popup = new PopupMenu(requireContext(), anchorView);
        popup.getMenuInflater().inflate(R.menu.task_item_options_menu, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.action_edit_task) {
                AddTaskDialogFragment editDialog = AddTaskDialogFragment.newInstance(task);
                editDialog.show(getParentFragmentManager(), "EditTaskDialogFromProjects");
                return true;
            } else if (itemId == R.id.action_delete_task) {
                confirmAndDeleteTaskInFragment(task);
                return true;
            }
            return false;
        });
        popup.show();
    }

    @Override
    public void onTaskSelectionChanged(Task task, boolean isSelected) {
        // Same logic as other fragments
        if (isSelected) {
            if (!selectedTasksList.contains(task)) selectedTasksList.add(task);
        } else {
            selectedTasksList.remove(task);
        }
        if (taskAdapter != null) taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
        updateContextualActionBar();
    }

    // --- Contextual Action Bar Methods  ---
    private void updateContextualActionBar() {
        if (contextualActionBar == null) return;

        boolean hasSelection = !selectedTasksList.isEmpty();
        contextualActionBar.setVisibility(hasSelection ? View.VISIBLE : View.GONE);

        if (hasSelection) {
            if (tvSelectedCountContextual != null) {
                tvSelectedCountContextual.setText(selectedTasksList.size() + " selected");
            }
            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setEnabled(true);
            if (btnDeleteSelectedContextual != null) btnDeleteSelectedContextual.setEnabled(true);
            if (btnCloseContextualAction != null) btnCloseContextualAction.setEnabled(true);

            if (btnSelectAllContextual != null) {
                List<Task> currentDisplayedTasks = taskAdapter.getCurrentList();
                int totalActiveDisplayableTasks = 0;
                if (currentDisplayedTasks != null) {
                    for (Task t : currentDisplayedTasks) {
                        if (t.getStatus() != Task.Status.COMPLETED) totalActiveDisplayableTasks++;
                    }
                }
                btnSelectAllContextual.setEnabled(selectedTasksList.size() < totalActiveDisplayableTasks);
            }
        } else {

            if (btnCompleteSelectedContextual != null) btnCompleteSelectedContextual.setEnabled(false);
            if (btnDeleteSelectedContextual != null) btnDeleteSelectedContextual.setEnabled(false);
            if (btnSelectAllContextual != null) btnSelectAllContextual.setEnabled(true);
        }
    }
    private void clearSelectionMode() {
        selectedTasksList.clear();
        if (taskAdapter != null) {
            taskAdapter.clearSelectedTaskIdsForBulk();
        }
        updateContextualActionBar();
    }
    private void handleSelectAllTasks() {
        selectedTasksList.clear();
        List<Task> currentDisplayedTasks = taskAdapter.getCurrentList(); // Gets all tasks shown
        if (currentDisplayedTasks != null) {
            selectedTasksList.addAll(currentDisplayedTasks); // Add all of them
        }
        if (taskAdapter != null) taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
        updateContextualActionBar();
    }
    private void handleCompleteSelectedTasks() {
        if (selectedTasksList.isEmpty()) return;
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());
        executor.execute(() -> {
            for (Task task : new ArrayList<>(selectedTasksList)) {
                task.setStatus(Task.Status.COMPLETED);
                task.setReminded(false);
                taskService.save(task);
            }
            handler.post(() -> {
                selectedTasksList.clear();
                if (taskAdapter != null) taskAdapter.clearSelectedTaskIdsForBulk(); // Clear adapter's selection
                loadTasksForFragment();     // Reload data (will filter out completed)
                updateContextualActionBar(); // Hide bar
                Toast.makeText(getContext(), "Tasks marked complete", Toast.LENGTH_SHORT).show();
            });
        });
    }
    private void handleDeleteSelectedTasks() {
        selectedTasksList.clear();
        List<Task> currentDisplayedTasks = taskAdapter.getCurrentList();
        if (currentDisplayedTasks != null) {
            for (Task task : currentDisplayedTasks) {
                if (task.getStatus() != Task.Status.COMPLETED) {
                    selectedTasksList.add(task);
                }
            }
        }
        if (taskAdapter != null) {
            taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList);
        }
        updateContextualActionBar();
    }
    private void confirmAndDeleteTaskInFragment(Task task) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Confirm Delete")
                .setMessage("Delete task: '" + task.getTitle() + "'?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());
                    executor.execute(() -> {
                        taskService.deleteTask(task.getId());
                        handler.post(()-> {

                            selectedTasksList.remove(task);
                            if (taskAdapter != null) taskAdapter.setSelectedTaskIdsForBulk(selectedTasksList); // Update adapter
                            loadTasksForFragment(); // Refresh the list
                            updateContextualActionBar(); // Update bar state
                            Toast.makeText(getContext(), "Task deleted", Toast.LENGTH_SHORT).show();
                        });
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

}
