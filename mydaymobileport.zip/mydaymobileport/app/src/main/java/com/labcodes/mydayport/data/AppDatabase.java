package com.labcodes.mydayport.data;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import android.content.Context; // Import Android Context

import com.labcodes.mydayport.model.Task;
import com.labcodes.mydayport.repositories.TaskDao;
import com.labcodes.mydayport.data.converters.DateConverter;
import com.labcodes.mydayport.data.converters.DateTimeConverter;
import com.labcodes.mydayport.data.converters.PriorityConverter;
import com.labcodes.mydayport.data.converters.StatusConverter;
import com.labcodes.mydayport.model.DailyCompletionStat;


@Database(entities = {Task.class,}, version = 1, exportSchema = false)
@TypeConverters({DateConverter.class, DateTimeConverter.class, PriorityConverter.class, StatusConverter.class})
public abstract class AppDatabase extends RoomDatabase {

    public abstract TaskDao taskDao();

    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "myday_database") // Database file name
                            // .fallbackToDestructiveMigration() // For development: if schema changes, wipes DB
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
