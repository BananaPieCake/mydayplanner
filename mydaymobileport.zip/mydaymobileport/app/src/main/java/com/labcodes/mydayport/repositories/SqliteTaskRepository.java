package com.labcodes.mydayport.repositories;

import android.content.Context; // Required to get database instance
import androidx.lifecycle.LiveData; // Optional: If you want to use LiveData for reactive UI
// For now, let's stick to direct List returns

import com.labcodes.mydayport.data.AppDatabase;

import com.labcodes.mydayport.model.DailyCompletionStat;
import com.labcodes.mydayport.model.PriorityCountStat;
import com.labcodes.mydayport.model.Task;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.LinkedHashMap; // For getTasksCompletedPerDay

public class SqliteTaskRepository implements TaskRepository {

    private TaskDao taskDao;
    // We use an ExecutorService for this.
    private ExecutorService executorService;

    public SqliteTaskRepository(Context context) {
        AppDatabase db = AppDatabase.getDatabase(context);
        this.taskDao = db.taskDao();
        this.executorService = Executors.newSingleThreadExecutor(); // Simple single-thread executor
    }

    @Override
    public Task save(final Task task) {
        Future<Task> future = executorService.submit(() -> {
            Task existingTask = taskDao.findTaskById(task.getId());
            if (existingTask != null) {
                System.out.println("SqliteTaskRepository: Updating task ID: " + task.getId());
                taskDao.updateTask(task);
            } else {
                System.out.println("SqliteTaskRepository: Inserting new task ID: " + task.getId());
                taskDao.insertTask(task);
            }
            return task;
        });

        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Optional<Task> findById(final String id) {
        Future<Optional<Task>> future = executorService.submit(() -> Optional.ofNullable(taskDao.findTaskById(id)));
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return Optional.empty();
        }
    }

    @Override
    public List<Task> findAll() {
        Future<List<Task>> future = executorService.submit(() -> taskDao.getAllTasks());
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public List<Task> findActiveTasks() {
        Future<List<Task>> future = executorService.submit(() -> taskDao.findActiveTasks());
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public List<Task> searchActiveTasks(final String searchTerm) {
        String searchPattern = "%" + searchTerm.toLowerCase() + "%";
        Future<List<Task>> future = executorService.submit(() -> taskDao.searchActiveTasks(searchPattern));
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public boolean deleteById(final String id) {
        Future<Boolean> future = executorService.submit(() -> {
            int rowsDeleted = taskDao.deleteTaskById(id);
            return rowsDeleted > 0;
        });
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Map<LocalDate, Long> getTasksCompletedPerDay(final LocalDate startDate, final LocalDate endDate) {
        Future<Map<LocalDate, Long>> future = executorService.submit(() -> {
            List<DailyCompletionStat> stats = taskDao.getTasksCompletedPerDay(startDate, endDate);
            Map<LocalDate, Long> resultMap = new LinkedHashMap<>();
            for (DailyCompletionStat stat : stats) {
                resultMap.put(stat.dueDate, (long) stat.count);
            }
            return resultMap;
        });
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return new LinkedHashMap<>();
        }
    }

    // New method needed by mainInterface.loadTasks()
    public List<Task> getActiveTasksByDate(final LocalDate date) {
        Future<List<Task>> future = executorService.submit(() -> taskDao.findActiveTasksByDate(date));
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }


    @Override
    public Map<Task.Priority, Long> getTaskCountByPriority() {
        Future<Map<Task.Priority, Long>> future = executorService.submit(() -> {
            List<PriorityCountStat> statsFromDao = taskDao.getTaskCountByPriority(); // Call DAO
            Map<Task.Priority, Long> resultMap = new LinkedHashMap<>();

            // Initialize map with all priorities to ensure all slices appear (even if count is 0)
            // and to control the order in the pie chart if LinkedHashMap's order is used.
            for (Task.Priority p : Task.Priority.values()) {
                resultMap.put(p, 0L); // Initialize with 0
            }

            // Populate with actual counts from DAO
            for (PriorityCountStat stat : statsFromDao) {
                if (stat.priority != null) { // Should always have a priority due to GROUP BY
                    resultMap.put(stat.priority, (long) stat.count);
                }
            }
            return resultMap;
        });
        try {
            return future.get();
        } catch (Exception e) {
            e.printStackTrace();
            return new LinkedHashMap<>(); // Return empty on error
        }
    }

    // Example for findTasksByDate (Today's view)
    @Override
    public List<Task> findTasksByDate(LocalDate date, boolean activeOnly, Task.Priority priorityFilter, Task.Status statusFilter, String sortOrder) {
        // This specific combination now maps to a DAO method
        // Assuming 'activeOnly' means status != COMPLETED (which is in the DAO query)
        // Assuming 'statusFilter' isn't used here if 'activeOnly' covers it for "Today"
        Future<List<Task>> future = executorService.submit(() ->
                taskDao.findTodayTasksFiltered(date, priorityFilter, (priorityFilter == null))
        );
        try { return future.get(); } catch (Exception e) { e.printStackTrace(); return new ArrayList<>(); }
    }

    @Override
    public List<Task> findTasksGeneral(Task.Status statusFilter, Task.Priority priorityFilter, String sortOrder) {
        // This maps to the more complex DAO query for projects
        Future<List<Task>> future = executorService.submit(() ->
                taskDao.findProjectTasksFilteredAndSorted(
                        statusFilter, (statusFilter == null),
                        priorityFilter, (priorityFilter == null),
                        sortOrder != null ? sortOrder : "DEFAULT_DUE_DATE_ASC" // Provide a default sort
                )
        );
        try { return future.get(); } catch (Exception e) { e.printStackTrace(); return new ArrayList<>(); }
    }

    @Override
    public List<Task> findTasksByDateRange(LocalDate startDate, LocalDate endDate,
                                           boolean activeOnly, Task.Priority priorityFilter,
                                           Task.Status statusFilter, String sortOrder) {
        System.out.println("SqliteTaskRepository.findTasksByDateRange: " + startDate + " to " + endDate +
                ", activeOnly: " + activeOnly + ", prioFilter: " + priorityFilter +
                ", statusFilter: " + statusFilter + ", sort: " + sortOrder);
        boolean daoActiveOnlyIsFalse = !activeOnly;

        String daoSortOrder = (sortOrder != null) ? sortOrder : "DUE_DATE_ASC"; // Default sort

        Future<List<Task>> future = executorService.submit(() ->
                taskDao.findTasksInDateRangeFilteredAndSorted(
                        startDate, endDate,
                        daoActiveOnlyIsFalse,
                        statusFilter, (statusFilter == null),
                        priorityFilter, (priorityFilter == null),
                        daoSortOrder
                )
        );
        try {
            List<Task> result = future.get();
            System.out.println("SqliteTaskRepository.findTasksByDateRange: Fetched " + result.size() + " tasks.");
            return result;
        } catch (Exception e) {
            System.err.println("SqliteTaskRepository.findTasksByDateRange: Exception - " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

}