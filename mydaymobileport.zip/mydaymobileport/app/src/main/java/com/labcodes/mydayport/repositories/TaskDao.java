package com.labcodes.mydayport.repositories;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.labcodes.mydayport.model.DailyCompletionStat;
import com.labcodes.mydayport.model.PriorityCountStat;
import com.labcodes.mydayport.model.Task; // Your Task entity
import java.util.List;
import java.time.LocalDate;

@Dao
public interface TaskDao {

    // Dao = Data Access Object
    // why?


    @Insert(onConflict = OnConflictStrategy.REPLACE) // If ID exists, replace it
    void insertTask(Task task);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAllTasks(List<Task> tasks);

    @Update
    void updateTask(Task task);

    @Delete
    void deleteTask(Task task);

    @Query("DELETE FROM tasks WHERE id = :taskId") // Query to delete by ID
    int deleteTaskById(String taskId); // Returns number of rows deleted

    @Query("SELECT * FROM tasks WHERE id = :taskId")
    Task findTaskById(String taskId); // Returns a single Task or null

    @Query("SELECT * FROM tasks ORDER BY due_date ASC, creation_timestamp DESC")
    List<Task> getAllTasks(); // Gets all tasks

    @Query("SELECT * FROM tasks WHERE status != 'COMPLETED' OR status IS NULL ORDER BY due_date ASC, creation_timestamp DESC")
    List<Task> findActiveTasks();

    @Query("SELECT * FROM tasks WHERE due_date = :date AND (status != 'COMPLETED' OR status IS NULL) ORDER BY creation_timestamp DESC")
    List<Task> findActiveTasksByDate(LocalDate date);

    @Query("SELECT * FROM tasks WHERE (LOWER(title) LIKE LOWER(:searchTerm) OR LOWER(description) LIKE LOWER(:searchTerm)) " +
            "AND (status != 'COMPLETED' OR status IS NULL) ORDER BY due_date ASC, creation_timestamp DESC")
    List<Task> searchActiveTasks(String searchTerm);

    // For statistics (example)
    @Query("SELECT due_date, COUNT(*) as count FROM tasks WHERE status = 'COMPLETED' AND due_date BETWEEN :startDate AND :endDate GROUP BY due_date ORDER BY due_date ASC")
    List<DailyCompletionStat> getTasksCompletedPerDay(LocalDate startDate, LocalDate endDate);

    @Query("DELETE FROM tasks") // For import replace all
    void deleteAllTasks();


    @Query("SELECT priority, COUNT(*) as count FROM tasks WHERE status != 'COMPLETED' GROUP BY priority")
    List<PriorityCountStat> getTaskCountByPriority();

    @Query("SELECT * FROM tasks WHERE due_date = :date " +
            "AND (:priorityIsNull OR priority = :priorityValue) " +
            "AND (status != 'COMPLETED' OR status IS NULL) " +
            "ORDER BY reminder_date_time ASC, creation_timestamp ASC")
    List<Task> findTodayTasksFiltered(LocalDate date, Task.Priority priorityValue, boolean priorityIsNull);

    @Query("SELECT * FROM tasks WHERE (:statusIsNull OR status = :statusValue) " +
            "AND (:priorityIsNull OR priority = :priorityValue) " +
            "ORDER BY " +
            "CASE :sortOrder WHEN 'PRIORITY' THEN " +
            "  CASE priority WHEN 'URGENT' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 WHEN 'LOW' THEN 4 ELSE 5 END " +
            "ELSE " +
            "  due_date " +
            "END ASC, " +
            "CASE :sortOrder WHEN 'PRIORITY' THEN due_Date ELSE creation_timestamp END ASC")
    List<Task> findProjectTasksFilteredAndSorted(Task.Status statusValue, boolean statusIsNull,
                                                 Task.Priority priorityValue, boolean priorityIsNull,
                                                 String sortOrder);

    @Query("SELECT * FROM tasks WHERE " +
            "due_date BETWEEN :startDate AND :endDate " +
            "AND (:activeOnlyIsFalse OR (status != 'COMPLETED' OR status IS NULL)) " +
            "AND (:statusFilterIsNull OR status = :statusValue) " +
            "AND (:priorityFilterIsNull OR priority = :priorityValue) " +
            "ORDER BY " +
            "CASE :sortOrder WHEN 'DUE_DATE_ASC' THEN due_date END ASC, " +
            "CASE :sortOrder WHEN 'DUE_DATE_DESC' THEN due_date END DESC, " +
            "CASE :sortOrder WHEN 'PRIORITY' THEN CASE priority WHEN 'URGENT' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 WHEN 'LOW' THEN 4 ELSE 5 END END ASC, " +
            "creation_timestamp DESC")
    List<Task> findTasksInDateRangeFilteredAndSorted(
            LocalDate startDate, LocalDate endDate,
            boolean activeOnlyIsFalse,
            Task.Status statusValue, boolean statusFilterIsNull,
            Task.Priority priorityValue, boolean priorityFilterIsNull,
            String sortOrder
    );
}
