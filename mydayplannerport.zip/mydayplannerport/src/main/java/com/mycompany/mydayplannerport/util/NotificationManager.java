/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mydayplannerport.util;

import java.awt.Taskbar;
import java.awt.Toolkit;
import javax.swing.JFrame;
/**
 *
 * @author Miguel Pogi
 */
public class NotificationManager {
    private static JFrame mainApplicationFrame; // Optional: for window-specific attention

    // Call this once at application startup, perhaps after main frame is created
    public static void initialize(JFrame frame) {
        mainApplicationFrame = frame;

        // One-time setup for how the app requests attention
        if (mainApplicationFrame != null && Taskbar.isTaskbarSupported()) {
            Taskbar taskbar = Taskbar.getTaskbar();
            if (taskbar.isSupported(Taskbar.Feature.USER_ATTENTION)) {
                // This makes the window itself request attention if it's not active
                // when setWindowModified(true) is called, or if requestUserAttention(true) is called.
                // You might not need setWindowModified if you always call requestUserAttention.
                // mainApplicationFrame.getRootPane().putClientProperty("apple.awt.windowModified", Boolean.TRUE);
            }
        }
    }

    public static void indicateNewReminder(String taskTitle) {
        System.out.println("NotificationManager: Indicating new reminder for - " + taskTitle);

        // 1. Play Sound
        try {
            Toolkit.getDefaultToolkit().beep();
        } catch (Exception e) {
            System.err.println("NotificationManager: Beep sound error - " + e.getMessage());
        }

        // 2. Request OS User Attention
        if (Taskbar.isTaskbarSupported()) {
            Taskbar taskbar = Taskbar.getTaskbar();

            if (taskbar.isSupported(Taskbar.Feature.USER_ATTENTION)) {
                // Request attention for the application as a whole.
                // The 'critical' flag (second boolean) can influence behavior.
                // 'true' might make it try to steal focus if the main window is not active.
                // 'false' is usually a less intrusive bounce/flash.
                boolean requestWindowFocus = mainApplicationFrame != null && !mainApplicationFrame.isActive();
                taskbar.requestUserAttention(true, requestWindowFocus);
            }

            // Optional: Set a badge (e.g., "!" or a count) - mainly for macOS
            if (taskbar.isSupported(Taskbar.Feature.ICON_BADGE_TEXT)) {
                taskbar.setIconBadge("!"); // Or a number of pending reminders
            }
        } else {
            System.out.println("NotificationManager: Taskbar features not supported for attention request.");
        }
    }

    public static void clearReminderIndication() {
        System.out.println("NotificationManager: Clearing reminder indication (attempted).");
        if (Taskbar.isTaskbarSupported()) {
            Taskbar taskbar = Taskbar.getTaskbar();
            // Clearing USER_ATTENTION is often handled by OS when app gains focus.
            // Clearing the badge is explicit:
            if (taskbar.isSupported(Taskbar.Feature.ICON_BADGE_TEXT)) {
                taskbar.setIconBadge(null); // Clear badge
            }
        }
    }

    // Private constructor to prevent instantiation if all methods are static
    private NotificationManager() {}
}

