/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mydayplannerport.util;

import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Miguel Pogi
 */
public class DatabaseConnection {

    // H2 Database URL Configuration
    // Stores the DB file in a 'mydayplanner_data' subdirectory in the user's home folder
    // Example: C:\Users\YourUser\mydayplanner_data\mydaydb.mv.db
    // The ';AUTO_SERVER=TRUE' allows multiple connections within the same JVM if needed (useful for some tools/debugging)
    // The ';DB_CLOSE_DELAY=-1' keeps the DB open in memory even if the last connection closes (helps performance sometimes)
    private static final String H2_URL = "jdbc:h2:~/mydayplanner_data/mydaydb;AUTO_SERVER=TRUE;DB_CLOSE_DELAY=0";
    // For H2 embedded, user/pass are often simple or not strictly needed unless configured
    private static final String H2_USER = "sa"; // Default H2 user
    private static final String H2_PASSWORD = ""; // Default H2 password is empty

    static {
        // Load the H2 driver class (optional with modern JDBC, but good practice)
        try {
            Class.forName("org.h2.Driver");
            System.out.println("H2 JDBC Driver loaded successfully.");
        } catch (ClassNotFoundException e) {
            System.err.println("FATAL ERROR: H2 JDBC Driver not found! Make sure h2 dependency is in pom.xml.");
            e.printStackTrace();
            // Consider throwing a RuntimeException to halt application startup
            // throw new RuntimeException("H2 Driver not found", e);
        }

        // --- Initialize Database Schema ---
        // This block runs ONCE when the class is loaded.
        // It ensures the necessary tables exist.
        initializeDatabase();
    }

    /**
     * Gets a connection to the H2 embedded database.
     *
     * @return A JDBC Connection object.
     * @throws SQLException if a database access error occurs.
     */
    
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(H2_URL, H2_USER, H2_PASSWORD);
    }


    /**
     * Creates the required tables if they don't already exist.
     * This is crucial for the first time the application runs.
     */
    private static void initializeDatabase() {
        try (Connection conn = getConnection(); // This will create the DB if it doesn't exist
             Statement stmt = conn.createStatement()) {
            System.out.println("Attempting to execute CREATE TABLE statement...");
            String createTaskTableSql = "CREATE TABLE IF NOT EXISTS task (" +
                    "id VARCHAR(36) PRIMARY KEY, " +
                    "title VARCHAR(255) NOT NULL, " +
                    "description TEXT, " +
                    "creationTimeStamp TIMESTAMP, " +
                    "dueDate DATE, " +
                    "reminderDateTime TIMESTAMP, " +
                    "priority VARCHAR(20), " +
                    "status VARCHAR(20), " +         
                    "reminded BOOLEAN DEFAULT FALSE, " + 
                    "category VARCHAR(100) NULL" +
                    ")";
            System.out.println("Executing SQL: " + createTaskTableSql); // Print the SQL
            stmt.execute(createTaskTableSql);
            System.out.println("Checked/Created TASK table (hopefully with reminded column).");
        } catch (SQLException e) {
            System.err.println("CRITICAL ERROR during database initialization (table creation):");
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize database tables.", e); // Fail fast
        }
    }


    // Private constructor to prevent instantiation
    private DatabaseConnection() {}

}
