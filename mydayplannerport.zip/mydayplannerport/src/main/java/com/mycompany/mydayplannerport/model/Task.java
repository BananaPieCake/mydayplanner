/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mydayplannerport.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;


/**
 *
 * @author Miguel Pogi
 */
public class Task {
    
    
    public enum Priority { LOW, MEDIUM, HIGH, URGENT }
    public enum Status { PENDING, IN_PROGRESS, COMPLETED, POSTPONE}
    
    
    private String id;
    
    private String title;
    private String description;
    private LocalDateTime creationTimeStamp;
    private LocalDate dueDate;
    private boolean reminded;
    
    private LocalDateTime reminderDateTime;
    private Priority priority;
    private Status status;
    private String category; 
    
    // for subtask
    // private String parentTaskId; // alternative lng para sa subtask pero baka wag kuna ilagay
    
    
    // --- ADD THIS NO-ARGUMENT CONSTRUCTOR for Jackson ---
    public Task() {
        this.status = Status.PENDING;
        this.priority = Priority.MEDIUM;
        this.reminded = false;

    }
    // --- END NO-ARGUMENT CONSTRUCTOR ---
    
    //CONSTRUCTORS
    // new task
    public Task(String title, String description, LocalDate dueDate){
        this.id = UUID.randomUUID().toString();
        this.title = Objects.requireNonNull(title, "Tittle cannot be null");
        this.description = description != null ? description : "";
        this.creationTimeStamp = LocalDateTime.now();
        this.dueDate = dueDate;
        this.status = Status.PENDING;
        this.priority = Priority.MEDIUM;
        this.reminded = false;
    
    }
    
    // loading task
    public Task(String id, String title, String description, LocalDateTime creationTimeStamp,
            LocalDate dueDate, LocalDateTime reminderDateTime,
            Priority priority, Status status, boolean reminded, String category) {
        this.id = id; // MUST assign the passed 'id'
        this.title = Objects.requireNonNull(title, "Title cannot be null");
        this.description = description != null ? description : "";
        this.creationTimeStamp = creationTimeStamp; // Use parameter
        this.dueDate = dueDate;
        this.reminderDateTime = reminderDateTime;
        this.priority = (priority != null) ? priority : Priority.MEDIUM; // Default if null
        this.status = (status != null) ? status : Status.PENDING;     // Default if null
        this.reminded = reminded;
        this.category = category;
    }
    
    
    // Getters (helps with encapsulation)
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public LocalDateTime getCreationTimeStamp() { return creationTimeStamp; }
    public LocalDate getDueDate() { return dueDate; }
    public LocalDateTime getReminderDateTime() { return reminderDateTime; }
    public Priority getPriority() { return priority; }
    public Status getStatus() { return status; }
    public boolean isReminded(){ return reminded;}
    public String getCategory() { return category; }

    
    
    // setters for mutables properties
    public void setId(String id) { this.id = id; }
    public void setTitle(String title) { this.title = Objects.requireNonNull(title, "Title cannot be null"); }
    public void setDescription(String description) { this.description = description != null ? description : ""; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public void setCreationTimeStamp(LocalDateTime creationTimeStamp) { this.creationTimeStamp = creationTimeStamp; }
    public void setReminderDateTime(LocalDateTime reminderDateTime) { this.reminderDateTime = reminderDateTime; }
    public void setPriority(Priority priority) { this.priority = priority; }
    public void setStatus(Status status) { this.status = status; }
    public void setReminded(boolean reminded){ this.reminded = reminded; }
    public void setCategory(String category) { this.category = category; } 
    
    
}
