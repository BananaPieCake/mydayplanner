/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mydayplannerport.repositories;

import com.mycompany.mydayplannerport.model.Task; 
import com.mycompany.mydayplannerport.util.DatabaseConnection; 

import java.sql.*; // Import core JDBC classes, likely not needed cause h2db?
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 *
 * @author Miguel Pogi
 */
public class H2TaskRepository implements TaskRepository {


    private static final String INSERT_TASK_SQL = "INSERT INTO task (id, title, description, creationTimeStamp, dueDate, reminderDateTime, priority, status, reminded, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SELECT_TASK_BY_ID_SQL = "SELECT id, title, description, creationTimeStamp, dueDate, reminderDateTime, priority, status, reminded, category FROM task WHERE id = ?";
    private static final String UPDATE_TASK_SQL = "UPDATE task SET title = ?, description = ?, dueDate = ?, reminderDateTime = ?, priority = ?, status = ?, reminded = ?, category = ? WHERE id = ?";
    private static final String DELETE_TASK_SQL = "DELETE FROM task WHERE id = ?";
    private static final String SELECT_ALL_TASKS_SQL =
    "SELECT id, title, description, creationTimestamp, dueDate, reminderDateTime, priority, status, reminded, category " +
    "FROM task ORDER BY dueDate ASC, creationTimestamp DESC";
    private static final String SEARCH_ACTIVE_TASKS_SQL =
    "SELECT id, title, description, creationTimeStamp, dueDate, reminderDateTime, priority, status, reminded, category " +
    "FROM task WHERE (LOWER(title) LIKE ? OR LOWER(description) LIKE ?) " +
    "AND (status != 'COMPLETED' OR status IS NULL) " + 
    "ORDER BY dueDate ASC, creationTimeStamp DESC";
    private static final String SELECT_ACTIVE_TASKS_SQL =
    "SELECT id, title, description, creationTimeStamp, dueDate, reminderDateTime, priority, status, reminded, category " +
    "FROM task WHERE (status != 'COMPLETED' OR status IS NULL) " + 
    "ORDER BY dueDate ASC, creationTimeStamp DESC";
    private static final String COUNT_COMPLETED_TASKS_PER_DAY_SQL =
        "SELECT dueDate, COUNT(*) as completed_count " +
        "FROM task " +
        "WHERE status = ? AND dueDate BETWEEN ? AND ? " + 
        "GROUP BY dueDate " +
        "ORDER BY dueDate ASC";
    
    
    @Override
    public Task save(Task task) {
        if (task == null || task.getId() == null) {
            System.err.println("H2TaskRepository.save: Attempted to save a null task or task with null ID.");
            return null;
        }
        System.out.println("H2TaskRepository.save: Received task with ID: " + task.getId() + ", Title: " + task.getTitle());

        Optional<Task> existing = findById(task.getId()); 

        if (existing.isPresent()) {
            System.out.println("H2TaskRepository.save: Task with ID " + task.getId() + " FOUND in DB. Calling update.");
            System.out.println("    Details of existing task found: ID=" + existing.get().getId() + ", Title=" + existing.get().getTitle());
            return update(task);
        } else {
            System.out.println("H2TaskRepository.save: Task with ID " + task.getId() + " NOT found in DB. Calling insert.");
            return insert(task); // This is where the error occurs if it gets here incorrectly
        }
    }

    private Task insert(Task task) {
       System.out.println("H2TaskRepository.insert: ATTEMPTING TO INSERT ID: " + task.getId() + ", Title: " + task.getTitle());
       try (Connection connection = DatabaseConnection.getConnection();
            PreparedStatement pstmt = connection.prepareStatement(INSERT_TASK_SQL)) {

            
            pstmt.setString(1, task.getId());
            pstmt.setString(2, task.getTitle());
            pstmt.setString(3, task.getDescription());
            pstmt.setObject(4, task.getCreationTimeStamp());
            pstmt.setObject(5, task.getDueDate());
            pstmt.setObject(6, task.getReminderDateTime());
            pstmt.setString(7, task.getPriority() != null ? task.getPriority().name() : null); 
            pstmt.setString(8, task.getStatus() != null ? task.getStatus().name() : null);
            pstmt.setBoolean(9, task.isReminded());
            pstmt.setString(10, task.getCategory());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
//            System.out.println("H2TaskRepository.insert: SUCCESS - Rows affected: " + affectedRows + " for ID: " + task.getId());
            return task;
            } else {
                System.err.println("H2TaskRepository.insert: FAILED - No rows affected for ID: " + task.getId());
                return null;
            }
        } catch (SQLException e) {
            System.err.println("H2TaskRepository.insert: SQL EXCEPTION for ID " + task.getId() + " - " + e.getMessage());
            e.printStackTrace();
            return null;
        }
        
    }

    private Task update(Task task) {
        try (Connection connection = DatabaseConnection.getConnection();
            PreparedStatement pstmt = connection.prepareStatement(UPDATE_TASK_SQL)) {

           pstmt.setString(1, task.getTitle());
           pstmt.setString(2, task.getDescription());
           pstmt.setObject(3, task.getDueDate());
           pstmt.setObject(4, task.getReminderDateTime());
           pstmt.setString(5, task.getPriority() != null ? task.getPriority().name() : null);
           pstmt.setString(6, task.getStatus() != null ? task.getStatus().name() : null);
           pstmt.setBoolean(7, task.isReminded());
           pstmt.setString(8, task.getCategory());
           pstmt.setString(9, task.getId()); 

           int affectedRows = pstmt.executeUpdate(); 

           if (affectedRows > 0) {
//               System.out.println("H2TaskRepository.update: Successfully updated task ID: " + task.getId() + " to status: " + task.getStatus());
               return task;
           } else {
               System.err.println("H2TaskRepository.update: FAILED to update task ID: " + task.getId() + " (task not found or no changes needed).");

               return null; 
           }
       } catch (SQLException e) {
           System.err.println("H2TaskRepository.update SQL Exception for task ID " + task.getId() + ": " + e.getMessage());
           e.printStackTrace();
           return null;
       }
    }

    @Override
    public Optional<Task> findById(String id) {
        if (id == null) {
            System.err.println("H2TaskRepository.findById: Received null ID to search for.");
            return Optional.empty();
        }
        System.out.println("H2TaskRepository.findById: Searching for task with ID: " + id);
        // String sql = SELECT_TASK_BY_ID_SQL; // Use your constant
        Task foundTask = null;
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(SELECT_TASK_BY_ID_SQL)) { // Use your constant
            pstmt.setString(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("H2TaskRepository.findById: Row FOUND in database for ID: " + id);
                foundTask = mapResultSetToTask(rs); // mapResultSetToTask will print its mapped ID
                if (foundTask != null) {
                     System.out.println("H2TaskRepository.findById: Mapped task - ID: " + foundTask.getId() + ", Title: " + foundTask.getTitle());
                } else {
                     System.err.println("H2TaskRepository.findById: mapResultSetToTask returned null for ID: " + id);
                }
            } else {
                System.out.println("H2TaskRepository.findById: Row NOT FOUND in database for ID: " + id);
            }
        } catch (SQLException e) {
            System.err.println("H2TaskRepository.findById: SQL Exception for ID " + id + ": " + e.getMessage());
            e.printStackTrace();
        }
        return Optional.ofNullable(foundTask);
    }

    @Override
    public List<Task> findAll() {
        List<Task> tasks = new ArrayList<>();
        System.out.println("H2TaskRepository.findAll: Fetching all tasks using SQL: " + SELECT_ALL_TASKS_SQL);
        try (Connection connection = DatabaseConnection.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_ALL_TASKS_SQL)) {

            int rowCountFromDb = 0;
            while (rs.next()) { // Is this loop even entered?
                rowCountFromDb++;
                System.out.println("H2TaskRepository.findAll: Processing row " + rowCountFromDb + " from ResultSet.");
                try {
                    Task mappedTask = mapResultSetToTask(rs); // <<< PROBLEM AREA
                    if (mappedTask != null) {
                        tasks.add(mappedTask);
                        System.out.println("H2TaskRepository.findAll: Successfully mapped and added task with ID: " + mappedTask.getId());
                    } else {
                        // This means mapResultSetToTask explicitly returned null
                        System.err.println("H2TaskRepository.findAll: mapResultSetToTask returned null for row " + rowCountFromDb);
                    }
                } catch (SQLException mapEx) {
                    // This means mapResultSetToTask threw an SQLException
                    System.err.println("H2TaskRepository.findAll: SQLException INSIDE mapResultSetToTask for row " + rowCountFromDb + ": " + mapEx.getMessage());
                    mapEx.printStackTrace();
                    // Because of this catch, the loop continues, and 'tasks' might remain empty
                } catch (Exception generalEx) {
                    // Catch any other unexpected runtime exceptions from mapping
                    System.err.println("H2TaskRepository.findAll: UNEXPECTED Exception INSIDE mapResultSetToTask for row " + rowCountFromDb + ": " + generalEx.getMessage());
                    generalEx.printStackTrace();
                }
            }
            System.out.println("H2TaskRepository.findAll: Finished ResultSet. Total rows processed from DB: " + rowCountFromDb + ". Tasks list size: " + tasks.size());
        } catch (SQLException e) {
            System.err.println("H2TaskRepository.findAll: SQL Exception during main query execution: " + e.getMessage());
            e.printStackTrace();
        }
        return tasks;
    }

    @Override
    public boolean deleteById(String id) {
         // COPY the implementation from MySqlTaskRepository
         // Ensure it uses DatabaseConnection.getConnection()
         try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(DELETE_TASK_SQL)) {
            pstmt.setString(1, id);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            // ... error handling ...
            return false;
        }
    }
    
    @Override 
    public List<Task> findActiveTasks() {
        List<Task> tasks = new ArrayList<>();
        System.out.println("H2TaskRepository.findActiveTasks: Fetching using SQL: " + SELECT_ACTIVE_TASKS_SQL);
        try (Connection connection = DatabaseConnection.getConnection();
             Statement stmt = connection.createStatement(); // Can use Statement if no params
             ResultSet rs = stmt.executeQuery(SELECT_ACTIVE_TASKS_SQL)) {
            while (rs.next()) {
                tasks.add(mapResultSetToTask(rs));
            }
        } catch (SQLException e) {
            System.err.println("H2TaskRepository.findActiveTasks: SQL Exception: " + e.getMessage());
            e.printStackTrace();
        }
        return tasks;
    }
    
    @Override
    public List<Task> searchActiveTasks(String searchTerm) {
        List<Task> tasks = new ArrayList<>();
        String searchPattern = "%" + searchTerm + "%"; // Add wildcards
        System.out.println("H2TaskRepository.searchActiveTasks: Searching for pattern: " + searchPattern);

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(SEARCH_ACTIVE_TASKS_SQL)) {
            pstmt.setString(1, searchPattern);
            pstmt.setString(2, searchPattern);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    tasks.add(mapResultSetToTask(rs));
                }
            }
            System.out.println("H2TaskRepository.searchActiveTasks: Found " + tasks.size() + " tasks.");
        } catch (SQLException e) {
            System.err.println("H2TaskRepository.searchActiveTasks: SQL Exception: " + e.getMessage());
            e.printStackTrace();
        }
        return tasks;
    }


    
    private Task mapResultSetToTask(ResultSet rs) throws SQLException {
    // Column names MUST match case in DB (e.g., "ID", "TITLE", "REMINDED")
        String id = rs.getString("ID");
        String title = rs.getString("TITLE");
        String description = rs.getString("DESCRIPTION");
        LocalDateTime creationTimeStamp = rs.getObject("CREATIONTIMESTAMP", LocalDateTime.class);
        LocalDate dueDate = rs.getObject("DUEDATE", LocalDate.class);
        LocalDateTime reminderDateTime = rs.getObject("REMINDERDATETIME", LocalDateTime.class);
        String priorityStr = rs.getString("PRIORITY");
        String statusStr = rs.getString("STATUS");
        boolean reminded = rs.getBoolean("REMINDED"); 
        String category = rs.getString("CATEGORY");

        System.out.println("mapResultSetToTask - Raw data: id=" + id + ", title=" + title + ", reminded=" + reminded);

        Task.Priority priorityEnum = null;
        if (priorityStr != null && !priorityStr.trim().isEmpty()) {
            try { priorityEnum = Task.Priority.valueOf(priorityStr.trim().toUpperCase()); }
            catch (IllegalArgumentException e) { System.err.println("mapResultSetToTask: Invalid priority: '" + priorityStr + "'");}
        }

        Task.Status statusEnum = null;
        if (statusStr != null && !statusStr.trim().isEmpty()) {
            try { statusEnum = Task.Status.valueOf(statusStr.trim().toUpperCase()); }
            catch (IllegalArgumentException e) { System.err.println("mapResultSetToTask: Invalid status: '" + statusStr + "'");}
        }

        // Uses the "loading" constructor
        Task task = new Task(id, title, description, creationTimeStamp, dueDate, reminderDateTime, priorityEnum, statusEnum, reminded, category);
        System.out.println("mapResultSetToTask - Constructed Task in memory - ID: " + task.getId());
        return task;
    }
    
    @Override
    public Map<LocalDate, Long> getTasksCompletedPerDay(LocalDate startDate, LocalDate endDate) {
        Map<LocalDate, Long> completedTasksPerDay = new LinkedHashMap<>(); // Use LinkedHashMap to maintain date order
        System.out.println("H2TaskRepository.getTasksCompletedPerDay: Fetching from " + startDate + " to " + endDate);

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(COUNT_COMPLETED_TASKS_PER_DAY_SQL)) {

            pstmt.setString(1, Task.Status.COMPLETED.name()); // Status to count
            pstmt.setObject(2, startDate); // Start of the date range
            pstmt.setObject(3, endDate);   // End of the date range

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    LocalDate date = rs.getObject("dueDate", LocalDate.class);
                    long count = rs.getLong("completed_count");
                    completedTasksPerDay.put(date, count);
                    System.out.println("  - Date: " + date + ", Completed: " + count);
                }
            }
        } catch (SQLException e) {
            System.err.println("H2TaskRepository.getTasksCompletedPerDay: SQL Exception: " + e.getMessage());
            e.printStackTrace();
            // Return empty map or throw exception
        }
        System.out.println("H2TaskRepository.getTasksCompletedPerDay: Found data for " + completedTasksPerDay.size() + " days.");
        return completedTasksPerDay;
    }
}
