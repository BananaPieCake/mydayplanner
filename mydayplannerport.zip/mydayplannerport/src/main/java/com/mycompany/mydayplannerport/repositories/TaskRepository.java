/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.mydayplannerport.repositories;

import java.util.List;
import java.util.Optional;
import com.mycompany.mydayplannerport.model.Task;
import java.time.LocalDate;
import java.util.Map;

/**
 *
 * @author Miguel Pogi
 */
public interface TaskRepository {
    
    Task save(Task task);
    
    Map<LocalDate, Long> getTasksCompletedPerDay(LocalDate startDate, LocalDate endDate);
    Optional<Task> findById(String idTask);
    
    
    List<Task> findAll();
    List<Task> findActiveTasks();
    List<Task> searchActiveTasks(String searchTerm);
    
    // Deletes a task by its unique ID. Returns true if deleted, false otherwise.
    boolean deleteById(String id);
    
    // implement finding by tags on services u can add that.
    // List<Task> findByDueDate(LocalDate date);
    // List<Task> findByStatus(Task.Status status);
    // List<Task> findByTag(String tag);
    
}
