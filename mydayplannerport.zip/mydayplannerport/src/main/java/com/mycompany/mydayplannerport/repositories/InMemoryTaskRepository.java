/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mydayplannerport.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import com.mycompany.mydayplannerport.model.Task;
import java.time.LocalDate;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 *
 * @author Miguel Pogi
 */
public class InMemoryTaskRepository implements TaskRepository{
    
    private final Map<String, Task> tasks = new ConcurrentHashMap<>();

    @Override
    public Task save(Task task) {
        Objects.requireNonNull(task, "Task cannot be null");
        Objects.requireNonNull(task.getId(), "Task ID cannot be null");
        tasks.put(task.getId(), task);
        return task; 
    }

    @Override
    public Optional<Task> findById(String id) {
        return Optional.ofNullable(tasks.get(id));
    }

    @Override
    public List<Task> findAll() {
        return new ArrayList<>(tasks.values());
    }
    
    @Override
    public List<Task> findActiveTasks() {
        System.out.println("InMemoryTaskRepository.findActiveTasks: Filtering in-memory tasks.");
        return tasks.values().stream()
                .filter(task -> task.getStatus() != Task.Status.COMPLETED &&
                                (task.getStatus() != Task.Status.POSTPONE || task.getStatus() == null)) // Adjust if POSTPONE should be excluded
                .collect(Collectors.toList());
    }

    // --- METHOD IMPLEMENTATION ---
    @Override
    public List<Task> searchActiveTasks(String searchTerm) {
        System.out.println("InMemoryTaskRepository.searchActiveTasks: Searching in-memory for: " + searchTerm);
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return findActiveTasks(); // If search is empty, return all active tasks
        }
        String lowerSearchTerm = searchTerm.toLowerCase();
        return tasks.values().stream()
                .filter(task -> task.getStatus() != Task.Status.COMPLETED &&
                                (task.getStatus() != Task.Status.POSTPONE || task.getStatus() == null)) // Filter active
                .filter(task -> (task.getTitle() != null && task.getTitle().toLowerCase().contains(lowerSearchTerm)) ||
                                (task.getDescription() != null && task.getDescription().toLowerCase().contains(lowerSearchTerm))) // Search title/desc
                .collect(Collectors.toList());
    }

    @Override
    public Map<LocalDate, Long> getTasksCompletedPerDay(LocalDate startDate, LocalDate endDate) {
        System.out.println("InMemoryTaskRepository.getTasksCompletedPerDay: Filtering from " + startDate + " to " + endDate);
        Map<LocalDate, Long> completedTasksPerDay = new LinkedHashMap<>();

        // Iterate through all tasks stored in memory
        for (Task task : tasks.values()) {
            // Check if the task is COMPLETED
            if (task.getStatus() == Task.Status.COMPLETED) {
                LocalDate taskDueDate = task.getDueDate(); // Assuming completion is based on due date for this stat

                // Check if the due date is not null and falls within the specified range (inclusive)
                if (taskDueDate != null &&
                    !taskDueDate.isBefore(startDate) &&
                    !taskDueDate.isAfter(endDate)) {

                    // Increment count for this date
                    completedTasksPerDay.put(taskDueDate, completedTasksPerDay.getOrDefault(taskDueDate, 0L) + 1);
                }
            }
        }

        // Optional: Fill in missing dates in the range with 0 counts if needed for charting
        // For simplicity, this current version only includes dates with actual completions.
        // If your chart needs all days in the range, you'd iterate from startDate to endDate
        // and put 0 for days not found in completedTasksPerDay.

        System.out.println("InMemoryTaskRepository.getTasksCompletedPerDay: Found data for " + completedTasksPerDay.size() + " days.");
        return completedTasksPerDay;
    }
    
    @Override
    public boolean deleteById(String id) {
        return tasks.remove(id) != null;
    }
}
