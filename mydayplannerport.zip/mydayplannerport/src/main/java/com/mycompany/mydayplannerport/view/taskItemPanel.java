/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mycompany.mydayplannerport.view;
import com.mycompany.mydayplannerport.model.Task;

import com.formdev.flatlaf.FlatClientProperties;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;  
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;
import java.time.format.DateTimeFormatter;
import java.time.LocalTime;
import java.util.List;

/**
 *
 * @author Miguel Pogi
 */
public class taskItemPanel extends javax.swing.JPanel {

    /**
     * Creates new form taskItemPanel inside jscrollpane
     */
    
    private Task currentTask; 
    private mainInterface parentFrame;
    
    private class PriorityDot extends JPanel {
        private Color dotColor = Color.LIGHT_GRAY; // Default color

        public PriorityDot() {
            // Set a fixed preferred size for the dot's area
            Dimension size = new Dimension(10, 10); 
            setPreferredSize(size);
            setMinimumSize(size);
            setMaximumSize(size);
            setOpaque(false); 
        }

        public void setColor(Color color) {
            this.dotColor = (color != null) ? color : Color.LIGHT_GRAY; // Handle null color
            repaint(); 
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g); 
            Graphics2D g2d = (Graphics2D) g.create();
            try {
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(dotColor);

                // Draw a oval. Use width/height of the panel.
                int diameter = Math.min(getWidth(), getHeight()) - 2; // slightly smaller than panel
                int x = (getWidth() - diameter) / 2;  // Center it
                int y = (getHeight() - diameter) / 2;  // Center it
                if (diameter > 0) { 
                    g2d.fillOval(x, y, diameter, diameter);
                }
            } finally {
                g2d.dispose();
            }
        }
    }
    
    public taskItemPanel(mainInterface parentFrame) {
        this.parentFrame = parentFrame;
        initComponents();
        
        this.setBackground(Color.WHITE);
        this.setOpaque(true);
        
        this.putClientProperty(FlatClientProperties.STYLE, "arc: 15");
        this.setMaximumSize(new Dimension(Integer.MAX_VALUE, this.getPreferredSize().height)); // size of task
        
        optionButton.putClientProperty("JButton.buttonType", "borderless");
        optionButton.setFocusPainted(false);
        optionButton.setContentAreaFilled(false); // Make background transparent
        optionButton.setBorder(null);
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 5, 10, 5));
        
        // -- check box -- //
//        completionCheckBox.setOpaque(true);
//        completionCheckBox.setContentAreaFilled(true);
        
        // -- info panel -- //
        tagLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(2, 5, 2, 5));
        tagLabel.putClientProperty(FlatClientProperties.STYLE, "arc: 10");
        tagLabel.setBackground(Color.LIGHT_GRAY);
        tagLabel.setText("Tag");
        String firstTag = "Academic";
        
        if ("Academic".equalsIgnoreCase(firstTag)) { 
            tagLabel.setBackground(Color.decode("#673AB7")); // Purple
            tagLabel.setForeground(Color.WHITE);
        } else if ("Personal".equalsIgnoreCase(firstTag)) { 
            tagLabel.setBackground(Color.decode("#FFC107")); // Amber
            tagLabel.setForeground(Color.BLACK);
        } else {
            tagLabel.setBackground(Color.LIGHT_GRAY); // Default
            tagLabel.setForeground(Color.DARK_GRAY);
        }
            tagLabel.setVisible(true);
        
       
        
        titleLable.setFont(titleLable.getFont().deriveFont(Font.BOLD));
        Color descriptionColor = Color.GRAY;
        
        // -- DESCRIPTION AREA RESIZE FIX -- //
        descriptionArea.setMaximumSize(new Dimension(300, Integer.MAX_VALUE)); // resize fix
        descriptionArea.setForeground(descriptionColor);
        timeLabel.setForeground(descriptionColor);
        
        System.out.println("TaskItemPanel constructor: Creating test task...");
        com.mycompany.mydayplannerport.model.Task testTask = new com.mycompany.mydayplannerport.model.Task(
            "My First Test Task",
            "This is the description for the test task to see how it looks.",
            java.time.LocalDate.now().plusDays(2)
        );
        testTask.setPriority(com.mycompany.mydayplannerport.model.Task.Priority.HIGH);
        // testTask.addTag("Work"); // If tags are enabled in Task.java

        setTaskData(testTask); // Call the method WITHIN this class
//        System.out.println("TaskItemPanel constructor: setTaskData called.");
        completionCheckBox.addActionListener(e -> toggleSelection());
        
        if (optionButton != null) { // check if component exists
            optionButton.addActionListener(e -> showOptionsMenu());
        }
    }
    
    /**
     * Completion method
     */
    
    private boolean isItemSelected = false;
    
    
    private void toggleSelection() {
        isItemSelected = completionCheckBox.isSelected(); // Update internal state based on checkbox
        System.out.println("TaskItemPanel '" + (currentTask != null ? currentTask.getTitle() : "Unknown") + "' selection toggled to: " + isItemSelected);
        if (parentFrame != null) {
            parentFrame.taskSelectionChanged(currentTask, isItemSelected); // Notify mainInterface
        }
        // No direct status change or visual update for completion here anymore
    }
    
    public void setItemSelectedForBulkAction(boolean selected) {
        this.isItemSelected = selected;
        this.completionCheckBox.setSelected(selected);
        // Optionally, call updateVisualsBasedOnStatusAndSelection() if you want
        // the visual style of the panel to change immediately based on this bulk selection state.
        // updateVisualsBasedOnStatusAndSelection();
    }
    
    
    public boolean isItemSelected() {
        return isItemSelected;
    }

    public Task getCurrentTask() { // Getter for the task object
        return currentTask;
    }
    
    
    // New method to update visual style based on completion status
    public void updateVisualsBasedOnStatusAndSelection() {
        if (currentTask == null) return;

        if (currentTask.getStatus() == Task.Status.COMPLETED) {
            // Example: Strikethrough title, dim colors
            // This requires HTML on JLabel or custom painting
            titleLable.setText("<html><strike>" + currentTask.getTitle() + "</strike></html>");
            titleLable.setForeground(Color.LIGHT_GRAY);
            descriptionArea.setForeground(Color.LIGHT_GRAY);
            timeLabel.setForeground(Color.LIGHT_GRAY);
            tagLabel.setForeground(Color.LIGHT_GRAY); 

        } else {
            // Reset to normal appearance
            titleLable.setText(currentTask.getTitle()); 
            titleLable.setForeground(Color.BLACK); 
            descriptionArea.setForeground(Color.GRAY); 
            timeLabel.setForeground(Color.GRAY);    
 
        }
    }
    
    
    /**
     * Edit function for the option button
     * 
     */
    private void showOptionsMenu() {
        if (currentTask == null || parentFrame == null) return; 

        javax.swing.JPopupMenu popupMenu = new javax.swing.JPopupMenu();

        javax.swing.JMenuItem editItem = new javax.swing.JMenuItem("Edit");
        editItem.addActionListener(evt -> {
            // Open AddTaskDialog in EDIT mode
            // Pass parentFrame, modal true, parentFrame's taskService, and currentTask
            addTaskDialog dialog = new addTaskDialog(
                this.parentFrame,
                true,
                this.parentFrame.getTaskService(), // Assumes getTaskService() is public in mainInterface
                this.currentTask
            );
            dialog.setLocationRelativeTo(this.parentFrame);
            dialog.setVisible(true);

            // After edit dialog closes, tell mainInterface to refresh its task list
            this.parentFrame.loadTasks();
        });
        popupMenu.add(editItem);

        javax.swing.JMenuItem deleteItem = new javax.swing.JMenuItem("Delete");
        deleteItem.addActionListener(evt -> {
            int confirm = javax.swing.JOptionPane.showConfirmDialog(
                this.parentFrame,
                "Are you sure you want to delete task: '" + currentTask.getTitle() + "'?",
                "Confirm Delete",
                javax.swing.JOptionPane.YES_NO_OPTION,
                javax.swing.JOptionPane.WARNING_MESSAGE
            );
            if (confirm == javax.swing.JOptionPane.YES_OPTION) {
                this.parentFrame.getTaskService().deleteTask(currentTask.getId());
                this.parentFrame.loadTasks();
            }
        });
        popupMenu.add(deleteItem);

        popupMenu.show(optionButton, 0, optionButton.getHeight());
    }
    
    
    
    /**
    * Populates the panel's components with data from the given Task object.
    *
    * @param task The Task object containing the data to display.
    */
    
    public void setTaskData(Task task) { 
        this.currentTask = task;
        if (task == null) {
            titleLable.setText("Error: No Task Data");
            descriptionArea.setText("");
            if(tagLabel != null) tagLabel.setVisible(false);
            if(priorityDotPanel != null) priorityDotPanel.setVisible(false);
            if(timeLabel != null) timeLabel.setText("");
            if(completionCheckBox != null) completionCheckBox.setSelected(false);
            return;
        }

        // --- Populate Components ---
        titleLable.setText(task.getTitle());
        descriptionArea.setText(task.getDescription());

        // --- Format and Set Time ---
        if (task.getReminderDateTime() != null) {
            // If there's a specific reminder time, format and display that
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("h:mm a"); // e.g., "2:00 PM"
            timeLabel.setText(task.getReminderDateTime().format(timeFormatter));
        } else if (task.getDueDate() != null) {
            // If no reminder time, but there's a due date, show that
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMM dd"); // e.g., "May 11"
            timeLabel.setText(task.getDueDate().format(dateFormatter));
        } else {
            timeLabel.setText(""); // No due date or reminder time
        }

        
        // -- set category tags
        String category = task.getCategory(); // Get the single category string
        if (category != null && !category.isEmpty()) {
            tagLabel.setText(category); // Set the text of your tagLabel

            // Set tag background/foreground based on category
            if ("Academic".equalsIgnoreCase(category)) {
                tagLabel.setBackground(Color.decode("#673AB7")); // Purple
                tagLabel.setForeground(Color.WHITE);
            } else if ("Personal".equalsIgnoreCase(category)) {
                tagLabel.setBackground(Color.decode("#4CAF50")); // Green
                tagLabel.setForeground(Color.WHITE);
            } else if ("Work".equalsIgnoreCase(category)) {
                tagLabel.setBackground(Color.decode("#2196F3")); // Blue
                tagLabel.setForeground(Color.WHITE);
            } else if ("Errands".equalsIgnoreCase(category)) {
                tagLabel.setBackground(Color.decode("#FF9800")); // Orange
                tagLabel.setForeground(Color.BLACK); // Good contrast for orange
            } else {
                // Default for uncategorized or unknown categories
                tagLabel.setBackground(Color.LIGHT_GRAY);
                tagLabel.setForeground(Color.DARK_GRAY);
            }
            tagLabel.setVisible(true);
        } else {
            tagLabel.setText(""); // Clear text if no category
            tagLabel.setVisible(false); // Hide the tagLabel if no category
        }
        

                // --- Set Priority Dot Appearance ---
        setPriorityDotColor(task.getPriority());


                // --- Set Checkbox Tooltip (Optional) ---
        completionCheckBox.setSelected(this.isItemSelected);
        updateVisualsBasedOnStatusAndSelection();

                // -- Completed vis
        this.currentTask = task;

         }


    

    private void setPriorityDotColor(com.mycompany.mydayplannerport.model.Task.Priority priority) {
        if (priority == null) {
            ((PriorityDot) priorityDotPanel).setColor(Color.LIGHT_GRAY); 
            priorityDotPanel.setToolTipText("No priority");
            priorityDotPanel.setVisible(false); 
            return;
        }

        Color dotColor = Color.GRAY;
        String tooltip = "Priority: ";

        switch (priority) {
            case LOW: dotColor = Color.decode("#4CAF50"); tooltip += "Low"; break; // Green
            case MEDIUM: dotColor = Color.decode("#FFC107"); tooltip += "Medium"; break; // Amber/Orange
            case HIGH: dotColor = Color.decode("#FF5722"); tooltip += "High"; break;   // Deep Orange/Reddish
            case URGENT: dotColor = Color.decode("#D32F2F"); tooltip += "Urgent"; break;  // Red
        }
        ((PriorityDot) priorityDotPanel).setColor(dotColor); // Use setter
        priorityDotPanel.setToolTipText(tooltip);
        priorityDotPanel.setVisible(true);
        priorityDotPanel.repaint();
    }
    
    
    

    
    
    
    
public static void main(String[] args) {
    try {
        javax.swing.UIManager.setLookAndFeel(new com.formdev.flatlaf.FlatLightLaf());
    } catch (javax.swing.UnsupportedLookAndFeelException ex) {
        System.err.println("Failed to initialize LaF");
    }

    
    javax.swing.JFrame testFrame = new javax.swing.JFrame("Test TaskItemPanel");
    testFrame.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
//    testFrame.add(new taskItemPanel()); 
    testFrame.pack(); // Size the frame to fit the panel's preferred size
    testFrame.setLocationRelativeTo(null); // Center
    testFrame.setVisible(true);
}
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        completionCheckBox = new javax.swing.JCheckBox();
        detailsPanel = new javax.swing.JPanel();
        titleLable = new javax.swing.JLabel();
        descriptionArea = new javax.swing.JTextArea();
        infoPanel = new javax.swing.JPanel();
        iconL = new javax.swing.JLabel();
        timeLabel = new javax.swing.JLabel();
        tagLabel = new javax.swing.JLabel();
        priorityDotPanel = new PriorityDot()
        ;
        optionButton = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new java.awt.BorderLayout());
        add(completionCheckBox, java.awt.BorderLayout.WEST);

        detailsPanel.setOpaque(false);
        detailsPanel.setLayout(new javax.swing.BoxLayout(detailsPanel, javax.swing.BoxLayout.Y_AXIS));

        titleLable.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        titleLable.setText("Task Title Placeholder");
        detailsPanel.add(titleLable);

        descriptionArea.setEditable(false);
        descriptionArea.setColumns(20);
        descriptionArea.setForeground(new java.awt.Color(100, 100, 100));
        descriptionArea.setLineWrap(true);
        descriptionArea.setRows(5);
        descriptionArea.setWrapStyleWord(true);
        descriptionArea.setBorder(null);
        descriptionArea.setOpaque(false);
        detailsPanel.add(descriptionArea);

        infoPanel.setOpaque(false);
        infoPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        iconL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/graphics/clock.png"))); // NOI18N
        infoPanel.add(iconL);

        timeLabel.setForeground(new java.awt.Color(100, 100, 100));
        timeLabel.setText("hh:mm am/pm");
        infoPanel.add(timeLabel);

        tagLabel.setForeground(new java.awt.Color(100, 100, 100));
        tagLabel.setText("Tag");
        tagLabel.setOpaque(true);
        infoPanel.add(tagLabel);

        javax.swing.GroupLayout priorityDotPanelLayout = new javax.swing.GroupLayout(priorityDotPanel);
        priorityDotPanel.setLayout(priorityDotPanelLayout);
        priorityDotPanelLayout.setHorizontalGroup(
            priorityDotPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        priorityDotPanelLayout.setVerticalGroup(
            priorityDotPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        infoPanel.add(priorityDotPanel);

        detailsPanel.add(infoPanel);

        add(detailsPanel, java.awt.BorderLayout.CENTER);

        optionButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/graphics/moreVert.png"))); // NOI18N
        add(optionButton, java.awt.BorderLayout.EAST);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox completionCheckBox;
    private javax.swing.JTextArea descriptionArea;
    private javax.swing.JPanel detailsPanel;
    private javax.swing.JLabel iconL;
    private javax.swing.JPanel infoPanel;
    private javax.swing.JButton optionButton;
    private javax.swing.JPanel priorityDotPanel;
    private javax.swing.JLabel tagLabel;
    private javax.swing.JLabel timeLabel;
    private javax.swing.JLabel titleLable;
    // End of variables declaration//GEN-END:variables
}
