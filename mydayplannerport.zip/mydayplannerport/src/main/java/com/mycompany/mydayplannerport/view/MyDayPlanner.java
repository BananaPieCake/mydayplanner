/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.mydayplannerport.view;
import com.mycompany.mydayplannerport.model.Task;
import com.mycompany.mydayplannerport.repositories.H2TaskRepository;
import com.mycompany.mydayplannerport.repositories.TaskRepository;
import com.mycompany.mydayplannerport.repositories.InMemoryTaskRepository;
import com.mycompany.mydayplannerport.services.TaskService;
import com.mycompany.mydayplannerport.services.ReminderService;
import static com.mycompany.mydayplannerport.util.DatabaseConnection.getConnection;

import com.formdev.flatlaf.FlatDarculaLaf;
import java.sql.Connection; 
import java.sql.SQLException;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.mycompany.mydayplannerport.util.NotificationManager;
import java.time.LocalDate;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Taskbar;
import java.awt.Toolkit;
import java.awt.TrayIcon;


/**
 *
 * @author Miguel Pogi
 */
public class MyDayPlanner {

    /**
     * @param args the command line arguments
     */
    
    private static ReminderService reminderServiceInstance;
    private static TrayIcon trayIcon; 
    private static Image defaultIconImage; 
    private static Image notificationIconImage; 
    
    public static void main(String[] args) {
       

        // -- set flatlaf first -- //
        try {
          UIManager.setLookAndFeel(new FlatLightLaf());
//          UIManager.setLookAndFeel(new FlatDarculaLaf()); // intellij's color scheme
//            UIManager.setLookAndFeel( new FlatDarkLaf() );   // Clean dark theme
            System.out.println("FlatLaf Look and Feel Set Successfully.");

        } catch (UnsupportedLookAndFeelException ex) {
            System.err.println("Failed to initialize FlatLaf theme. Using default L&F.");
            
            // ex.printStackTrace();
        }
        javax.swing.SwingUtilities.invokeLater(() -> {
            
        });
        // -- END OF FLATLAF -- //
       
        
        
        // --- DB Connection Check ---
        System.out.println("Attempting to connect to the database...");
        try (Connection conn = getConnection()) { 
            if (conn != null) {
                System.out.println("Successfully connected to the H2 database!");
                
            } else {
                
                System.err.println("Failed to connect to the H2 database (getConnection returned null).");
            }
        } catch (SQLException e) {
            System.err.println("SQL Exception during H2 database connection test:");
            e.printStackTrace();
        }
        // --- END OF DB CHECKING ---

        

        // --- Start the GUI on the EDT (event dispatch thread) ---
        java.awt.EventQueue.invokeLater(() -> {
            System.out.println("Initializing and showing mainInterface...");
            mainInterface mainAppWindow = new mainInterface(); 

            // --- Start Reminder Service AFTER GUI is initialized ---
            NotificationManager.initialize(mainAppWindow);

            // --- Start Reminder Service --- ///
            if (mainAppWindow.getTaskService() != null) {
                reminderServiceInstance = new ReminderService(mainAppWindow.getTaskService());
                reminderServiceInstance.start();
            } else {
                System.err.println("Could not start ReminderService: TaskService not available.");
            }
            
            mainAppWindow.setVisible(true);
            
            // window listener to stop the reminder service when the app closes
            mainAppWindow.addWindowListener(new java.awt.event.WindowAdapter() {
                
                @Override
                public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                    if (reminderServiceInstance != null && reminderServiceInstance.isRunning()) {
                        reminderServiceInstance.stop();
                    }
                }
                
                @Override
                public void windowActivated(java.awt.event.WindowEvent e){
                    NotificationManager.clearReminderIndication();
                }
            });
        });

        System.out.println("Main method finished scheduling GUI startup.");
    }
    
}
