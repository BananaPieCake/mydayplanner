/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mydayplannerport.services;

import com.mycompany.mydayplannerport.model.Task;
import com.mycompany.mydayplannerport.util.NotificationManager;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
/**
 *
 * @author Miguel Pogi
 */
public class ReminderService {
    
    private final TaskService taskService;
    private final ScheduledExecutorService scheduler;
    private boolean running = false;

    public ReminderService(TaskService taskService) {
        this.taskService = taskService;
        // Creates a single-threaded scheduler
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
    }

    public void start() {
        if (running) {
            System.out.println("ReminderService is already running.");
            return;
        }
        running = true;
        System.out.println("Starting ReminderService...");
        // Schedule the checkReminders task to run every 1 minute, after an initial delay of 0 seconds
        scheduler.scheduleAtFixedRate(this::checkReminders, 0, 1, TimeUnit.MINUTES);
        // For testing, you might use TimeUnit.SECONDS and a shorter interval like 10 seconds
        // scheduler.scheduleAtFixedRate(this::checkReminders, 0, 10, TimeUnit.SECONDS);
    }

    public void stop() {
        if (!running) {
            System.out.println("ReminderService is not running.");
            return;
        }
        System.out.println("Stopping ReminderService...");
        scheduler.shutdown();
        try {
            // Wait a while for existing tasks to terminate
            if (!scheduler.awaitTermination(10, TimeUnit.SECONDS)) {
                scheduler.shutdownNow(); // Cancel currently executing tasks
                // Wait a while for tasks to respond to being cancelled
                if (!scheduler.awaitTermination(10, TimeUnit.SECONDS))
                    System.err.println("Scheduler did not terminate");
            }
        } catch (InterruptedException ie) {
            scheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
        running = false;
        System.out.println("ReminderService stopped.");
    }

    private void checkReminders() {
        System.out.println("[" + LocalDateTime.now() + "] Checking for reminders...");
        List<Task> allTasks = taskService.getAllTasks(); 
        LocalDateTime now = LocalDateTime.now();
        System.out.println("Found " + allTasks.size() + " tasks to check.");

        boolean reminderFiredThisCycle = false;
        for (Task task : allTasks) {
        System.out.println("  Checking Task: '" + task.getTitle() + "'");
        System.out.println("    - Reminder Set At: " + (task.getReminderDateTime() != null ? task.getReminderDateTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) : "NULL"));
        System.out.println("    - Is Already Reminded: " + task.isReminded());
        System.out.println("    - Current Status: " + task.getStatus());

        if (task.getReminderDateTime() != null && !task.isReminded() && 
            (task.getReminderDateTime().isBefore(now) || task.getReminderDateTime().isEqual(now)) &&
             task.getStatus() != Task.Status.COMPLETED) {

            System.out.println("    REMINDER DUE for: " + task.getTitle());
            showNotification(task);
            task.setReminded(true);
            reminderFiredThisCycle = true;

            // CRITICAL: Persist this change!
            System.out.println("    Attempting to save task with reminded=true...");
            Task updatedTask = taskService.save(task); // Assumes save handles updates
            if (updatedTask != null && updatedTask.isReminded()) {
                System.out.println("    Task '" + updatedTask.getTitle() + "' successfully updated with reminded=true.");
            } else {
                System.err.println("    ERROR: Failed to update task '" + task.getTitle() + "' with reminded=true.");
            }
        } else if (task.getReminderDateTime() == null) {
            System.out.println("    - No reminderDateTime set.");
        } else if (task.isReminded()) {
            System.out.println("    - Already reminded.");
        } else if (task.getReminderDateTime().isAfter(now)) {
            System.out.println("    - Reminder is in the future.");
        } else if (task.getStatus() == Task.Status.COMPLETED) {
            System.out.println("    - Task is completed.");
        }
    }
    if (!reminderFiredThisCycle) {
         System.out.println("No reminders due this cycle.");
    }
    System.out.println("-------------------------------------------------");
    }

    private void showNotification(Task task) {
        // Ensure notification is shown on the EDT
        NotificationManager.indicateNewReminder(task.getTitle());
        SwingUtilities.invokeLater(() -> {
            String message = "Reminder for: " + task.getTitle() + "\n" +
                             (task.getDescription().isEmpty() ? "" : "Description: " + task.getDescription() + "\n") +
                             "Due: " + (task.getDueDate() != null ? task.getDueDate().toString() : "No due date");
            // Simple JOptionPane notification
            JOptionPane.showMessageDialog(null, // Parent component (null makes it appear centered)
                                          message,
                                          "Task Reminder!",
                                          JOptionPane.INFORMATION_MESSAGE);

            // TODO: Play a sound
            // try {
            //     java.awt.Toolkit.getDefaultToolkit().beep();
            //     // Or play a custom sound file
            // } catch (Exception e) {
            //     System.err.println("Error playing beep sound: " + e.getMessage());
            // }
        });
    }

    public boolean isRunning() {
        return running;
    }
}
