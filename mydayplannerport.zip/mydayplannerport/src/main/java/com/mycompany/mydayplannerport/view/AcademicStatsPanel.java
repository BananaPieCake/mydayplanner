/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mycompany.mydayplannerport.view;
import com.mycompany.mydayplannerport.services.TaskService;
import java.awt.BorderLayout;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import java.awt.Color; // For colors
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import javax.swing.JLabel;
import javax.swing.JPanel;


/**
 *
 * @author Miguel Pogi
 */
public class AcademicStatsPanel extends javax.swing.JPanel {

    private TaskService taskService;
    private JPanel chartDisplayPanel;
    
    public AcademicStatsPanel(TaskService service){
        this.taskService = service;
        initComponents();
        
        setLayout(new BorderLayout());
        chartDisplayPanel = new JPanel(new BorderLayout());
        add(chartDisplayPanel, BorderLayout.CENTER); // Add chartDisplayPanel to AcademicStatsPanel

        loadAndDisplayCharts();
    }
    
    private void loadAndDisplayCharts() {
    if (taskService == null) {
        // ... (handle null taskService) ...
        return;
    }  

    Map<LocalDate, Long> completedData = taskService.getTasksCompletedPerDayForLastNDays(7);
    System.out.println("AcademicStatsPanel: Received " + completedData.size() + " data points for daily completion chart.");

    chartDisplayPanel.removeAll(); // Clear previous content

        if (completedData.isEmpty()) {
            chartDisplayPanel.add(new JLabel("No task completion data to display chart."), BorderLayout.CENTER);
        } else {
            // 1. Create the JFreeChart Dataset
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMM dd");

            List<LocalDate> sortedDates = new ArrayList<>(completedData.keySet());
            Collections.sort(sortedDates);

            for (LocalDate date : sortedDates) {    
                // Arguments for addValue: value, seriesKey (rowKey), categoryKey (columnKey)
                dataset.addValue(completedData.getOrDefault(date, 0L), "Tasks Completed", date.format(dateFormatter));
            }

            // 2. Create the Chart
            JFreeChart barChart = ChartFactory.createBarChart(
                    "Tasks Completed Per Day (Last 7 Days)", // Chart title
                    "Date",                                 // X-axis label (Domain axis)
                    "Number of Tasks",                      // Y-axis label (Range axis)
                    dataset,                                // Data
                    PlotOrientation.VERTICAL,
                    true,                                   // Include legend?
                    true,                                   // Generate tooltips?
                    false                                   // Generate URLs?
            );

            // 3. Customize the Chart (Optional but recommended)
            CategoryPlot plot = barChart.getCategoryPlot();
            plot.setBackgroundPaint(Color.WHITE); // Chart background
            plot.setRangeGridlinePaint(Color.LIGHT_GRAY); // Horizontal grid lines

            BarRenderer renderer = (BarRenderer) plot.getRenderer();
            renderer.setSeriesPaint(0, new Color(102, 178, 255)); // Color for the "Tasks Completed" series (light blue)
            renderer.setDrawBarOutline(false); // Optional: remove bar outlines

            // To show values on top of bars (Item Labels)
            renderer.setDefaultItemLabelsVisible(true);
            // You can customize the item label font, color, position, and format
            // org.jfree.chart.labels.StandardCategoryItemLabelGenerator labelGenerator =
            // new org.jfree.chart.labels.StandardCategoryItemLabelGenerator("{2}", new java.text.DecimalFormat("0")); // {2} is the value
            // renderer.setDefaultItemLabelGenerator(labelGenerator);
            // renderer.setDefaultItemLabelFont(new Font("SansSerif", Font.BOLD, 10));
            // renderer.setDefaultPositiveItemLabelPosition(new org.jfree.chart.ui.ItemLabelPosition(
            // org.jfree.chart.ui.ItemLabelAnchor.OUTSIDE12, org.jfree.chart.ui.TextAnchor.BOTTOM_CENTER));


            // 4. Create and Add the ChartPanel
            ChartPanel chartPanel = new ChartPanel(barChart);
            chartDisplayPanel.add(chartPanel, BorderLayout.CENTER);
        }

        chartDisplayPanel.revalidate();
        chartDisplayPanel.repaint();
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
