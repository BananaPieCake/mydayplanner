/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.mydayplannerport.view;
import com.mycompany.mydayplannerport.view.taskItemPanel; 
import com.mycompany.mydayplannerport.model.Task;
import com.mycompany.mydayplannerport.repositories.H2TaskRepository;
import com.mycompany.mydayplannerport.repositories.TaskRepository;
import com.mycompany.mydayplannerport.services.TaskService;
import com.mycompany.mydayplannerport.services.ReminderService;
import com.mycompany.mydayplannerport.view.AcademicStatsPanel;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import javax.swing.JFileChooser;
import java.io.File;
import java.io.IOException;

import com.formdev.flatlaf.FlatClientProperties;
import java.awt.BorderLayout;
import java.awt.Component; 
import java.awt.Dimension; 
import javax.swing.Box;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.awt.Color; 
import java.awt.LayoutManager;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;



/**
 *
 * @author Miguel Pogi
 */
public class mainInterface extends javax.swing.JFrame {

    private TaskService taskService;
    private TaskRepository taskRepository;
    
    
    
    // --- Instance Variables for Selection ---
    private javax.swing.JButton selectedNavButton = null;
    private final Color selectedNavBgColor = new Color(230, 230, 250); // Adjust color
    private final Color defaultNavFgColor = Color.DARK_GRAY;
    private final Color selectedNavFgColor = new Color(102, 51, 255); // Adjust color
    
    public mainInterface() {
        initComponents();
        
        // -- declare call repo -- //
        this.taskRepository = new H2TaskRepository(); 
        this.taskService = new TaskService(this.taskRepository);
        System.out.println("TaskRepository and TaskService initialized in mainInterface.");
        
        
        
        styleNavButton(today);
        styleNavButton(weekView);
        styleNavButton(allProjects);
        styleNavButton(academicTask);
        if (importButton != null) { 
            styleNavButton(importButton);
            styleNavButton(exportButton);
        }
        
        handleNavSelection(today); //default nav selection
        
        // START DESIGN //
        // Set SidePanel Background
        
        Color seperatorColor = new Color(220, 220, 220);
        SidePanel.setBackground(java.awt.Color.WHITE); // Example light grey
        SidePanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 5, 10, 10)); // padding
        SidePanel.setOpaque(true);   
        SidePanel.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createMatteBorder(1, 1, 1, 1, seperatorColor), 
        BorderFactory.createEmptyBorder(1, 1, 1, 1) 
        ));
         
         
         // -- titleandsub panel --//
        titleAndSub.setAlignmentX(Component.LEFT_ALIGNMENT);
        titleAndSub.setMaximumSize(new Dimension(Integer.MAX_VALUE, titleAndSub.getPreferredSize().height));
        titleAndSub.setOpaque(false);
        titleAndSub.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,15,0)); // Bottom padding
        Title.setAlignmentX(Component.LEFT_ALIGNMENT);
        Sub.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // --- NavSection Panel ---
        NavSection.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 0, 10, 0));
        NavSection.setOpaque(false);
        NavSection.setAlignmentX(Component.LEFT_ALIGNMENT);
        NavSection.setMaximumSize(new Dimension(Integer.MAX_VALUE, NavSection.getPreferredSize().height));
        
        if (jSeparator2 != null) {
            jSeparator2.setAlignmentX(Component.LEFT_ALIGNMENT);
            jSeparator2.setMaximumSize(new Dimension(Integer.MAX_VALUE, jSeparator2.getPreferredSize().height));
        }

        // -- user profile -- //
        
        titleAndSub.setOpaque(false);
        NavSection.setOpaque(false);
        if (userProfilePanel != null) {
            userProfilePanel.setOpaque(false);
        }
        if (userNameRolePanel != null) { // If you declared it
            userNameRolePanel.setOpaque(false);
        }
        
        if (userProfilePanel != null) { 
            userProfilePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
            
        }
        
        
         
        // -- Main content | tab bar | searchAddBar -- // 
        MainContent.setOpaque(true);
        TopBar.setBackground(java.awt.Color.WHITE);
        TopBar.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createMatteBorder(1, 0, 1, 1, seperatorColor), 
        BorderFactory.createEmptyBorder(1, 1, 1, 1) 
        ));
        
        Color primaryPurple = Color.decode("#673AB7");
        addTaskButton.setBackground(primaryPurple);
        addTaskButton.setOpaque(true);
        
        
        viewTitleLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5,10,5,5)); 
        dateInfoPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(5,10,5,5));
        
        
        searchField.putClientProperty("JTextField.placeholderText", "Search tasks...");
        searchField.putClientProperty(FlatClientProperties.STYLE, "arc: 50");
        searchAddPanel.setBackground(java.awt.Color.WHITE);
        addTaskButton.putClientProperty("JButton.buttonType", "primary");
        addTaskButton.putClientProperty(FlatClientProperties.STYLE, "arc: 50");
        
        filterButton.putClientProperty(FlatClientProperties.STYLE, "arc: 50");
        sortButton.putClientProperty(FlatClientProperties.STYLE, "arc: 50");
        
        
        jScrollPane1.getViewport().setBackground(MainContent.getBackground()); 
        jScrollPane1.setBorder(null);
        
        // -- END OF DESIGN -- //
        
        // nav selection and it's settings
        if (today != null) { 
         handleNavSelection(today);
        } else if (!NavSection.getComponents()[0].equals(null)) {
            
            handleNavSelection((JButton)NavSection.getComponents()[0]);
        } else {
            loadTasks(); 
        }
        
        // export and import
        if (exportButton != null) {
            exportButton.addActionListener(e -> handleExportTasks());
        }
        
        if (importButton != null) {
            importButton.addActionListener(e -> handleImportTasks());
        }

        // -- BulkAction Button -- //
        if (bulkActionPanel != null) { // Check if it was created in designer
        bulkActionPanel.setVisible(false); // Initially hidden

        completeSelectedButton.addActionListener(e -> handleCompleteSelected());
        deleteSelectedButton.addActionListener(e -> handleDeleteSelected());
        deselectAllButton.addActionListener(e -> handleDeselectAll());
        selectAllButton.addActionListener(e -> handleSelectAll());
        }
        
        // -- SORT & SEARCH -- //
        searchField.addActionListener(e -> performSearch());
        
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) { performSearch(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { performSearch(); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { performSearch(); }
        });
        

        // -- TESTING TESKITEMPANEL -- //
        
//        taskItemPanel testItem = new taskItemPanel();
//        TaskContainer.add(testItem);
//        System.out.println("mainInterface constructor: Test TaskItemPanel added to TaskContainer.");
        // -- done testing phase -- //
        
        // -- load item from h2db to gui -- //
        System.out.println("mainInterface constructor: Calling loadTasks().");
        loadTasks();
        
        
        
        // -- REVALIDATION -- //
        SidePanel.revalidate();
        SidePanel.repaint();

        
    }
    
    /**
     * Completion task
     */
    
    // store selected list
    private List<Task> selectedTasks = new ArrayList<>();
    
    public void taskSelectionChanged(Task task, boolean isSelected) {
        if (isSelected) {
            if (!selectedTasks.contains(task)) {
                selectedTasks.add(task);
            }
        } else {
            selectedTasks.remove(task);
        }
        System.out.println("mainInterface: Selected tasks count: " + selectedTasks.size());
        updateBulkActionUI(); // New method
    }
    
    // -- SELECT METHOD AND FUNCTIONS -- //
    
    private void updateBulkActionUI() {
        if (bulkActionPanel == null) return;

        boolean hasSelection = !selectedTasks.isEmpty();
        bulkActionPanel.setVisible(hasSelection); // Show/hide the whole panel

        if (hasSelection) {
            selectedCountLabel.setText(selectedTasks.size() + " item(s) selected");
        }

        deselectAllButton.setEnabled(hasSelection);
        completeSelectedButton.setEnabled(hasSelection);
        deleteSelectedButton.setEnabled(hasSelection);


        int totalVisibleTasks = 0;
        for(Component comp : TaskContainer.getComponents()){
            if(comp instanceof taskItemPanel){
                if(((taskItemPanel) comp).getCurrentTask().getStatus() != Task.Status.COMPLETED){
                     totalVisibleTasks++;
                }
            }
        }
        selectAllButton.setEnabled(selectedTasks.size() < totalVisibleTasks);


        if (bulkActionPanel.getParent() != null) {
            bulkActionPanel.getParent().revalidate();
            bulkActionPanel.getParent().repaint();
        }
    }
    
    private void handleCompleteSelected() {
    if (selectedTasks.isEmpty()) return;
        System.out.println("Completing " + selectedTasks.size() + " tasks...");
        for (Task task : new ArrayList<>(selectedTasks)) { 
            task.setStatus(Task.Status.COMPLETED);
            taskService.save(task);
        }
        selectedTasks.clear();
        loadTasks();
        updateBulkActionUI(); 
    }
    
    private void handleDeleteSelected() {
    if (selectedTasks.isEmpty()) return;
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete " + selectedTasks.size() + " selected task(s)?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            System.out.println("Deleting " + selectedTasks.size() + " tasks...");
            for (Task task : new ArrayList<>(selectedTasks)) {
                taskService.deleteTask(task.getId());
            }
        }
        selectedTasks.clear();
        loadTasks();
        updateBulkActionUI(); // Hide the panel
    }
    
    
    private void handleDeselectAll() {
        System.out.println("Deselecting all tasks...");
        for (Component comp : TaskContainer.getComponents()) {
            if (comp instanceof taskItemPanel) {
                ((taskItemPanel) comp).setItemSelectedForBulkAction(false); 
            }
        }
        selectedTasks.clear();
        updateBulkActionUI(); // Hide the panel
    }
    
    private void handleSelectAll() {
        System.out.println("Selecting all visible tasks...");
        selectedTasks.clear(); // Start with a fresh selection list

        for (Component comp : TaskContainer.getComponents()) {
            if (comp instanceof taskItemPanel) {
                taskItemPanel itemPanel = (taskItemPanel) comp;
                Task currentTask = itemPanel.getCurrentTask(); // Assumes getCurrentTask() exists

                if (currentTask != null && currentTask.getStatus() != Task.Status.COMPLETED) { // Only select active tasks
                    itemPanel.setItemSelectedForBulkAction(true); // Visually check the box
                    if (!selectedTasks.contains(currentTask)) { // Add to list if not already there
                        selectedTasks.add(currentTask);
                    }
                }
            }
        }
        updateBulkActionUI(); // Update the label and ensure panel is visible
    }
    
    // -------------------------------------------------------------------------------------------------
    // -- search and sort -- //
    private String currentSearchTerm = null; 

    private void performSearch() {
        this.currentSearchTerm = searchField.getText().trim();
        loadTasks(); 
    }
    
    
    // -- filter -- //
    

    
    // -------------------------------------------------------------------------------------------------
    // -- Export function -- //
    private void handleExportTasks() {
        if (taskService == null) {
            JOptionPane.showMessageDialog(this, "Task service not available.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<Task> tasksToExport = taskService.getAllTasks(); // Get ALL tasks (including completed)

        if (tasksToExport.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks to export.", "Export Data", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Tasks As JSON");
        // Suggest a filename
        fileChooser.setSelectedFile(new File("myday_tasks_export.json"));
        // Set a file filter for JSON files (optional but good UX)
        javax.swing.filechooser.FileNameExtensionFilter filter = new javax.swing.filechooser.FileNameExtensionFilter(
                "JSON Files (*.json)", "json");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            // Ensure the file has a .json extension
            if (!fileToSave.getName().toLowerCase().endsWith(".json")) {
                fileToSave = new File(fileToSave.getParentFile(), fileToSave.getName() + ".json");
            }

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule()); // IMPORTANT for LocalDate/LocalDateTime
            objectMapper.enable(SerializationFeature.INDENT_OUTPUT); // Make JSON readable

            try {
                objectMapper.writeValue(fileToSave, tasksToExport);
                JOptionPane.showMessageDialog(this,
                        "Tasks exported successfully to:\n" + fileToSave.getAbsolutePath(),
                        "Export Successful", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                        "Error exporting tasks: " + e.getMessage(),
                        "Export Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }
    
    // -- Import Function -- //
    private void handleImportTasks() {
        if (taskService == null) {
            JOptionPane.showMessageDialog(this, "Task service not available.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Import Tasks from JSON");
        javax.swing.filechooser.FileNameExtensionFilter filter = new javax.swing.filechooser.FileNameExtensionFilter(
                "JSON Files (*.json)", "json");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showOpenDialog(this); // Use showOpenDialog for import

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToImport = fileChooser.getSelectedFile();

            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule()); // ESSENTIAL for LocalDate/Time
            // INDENT_OUTPUT is for writing, not needed for reading, but doesn't hurt
            // objectMapper.enable(SerializationFeature.INDENT_OUTPUT);

            try {
                // Read the JSON file into a List<Task>
                List<Task> importedTasks = objectMapper.readValue(fileToImport, new TypeReference<List<Task>>() {});

                if (importedTasks != null && !importedTasks.isEmpty()) {
                    // --- IMPORT STRATEGY DECISION ---
                    // Option 1: Replace all existing tasks (Simpler)
                    // Option 2: Merge with existing tasks (More complex - needs conflict resolution)

                    // For now, let's implement Option 1: Replace All
                    int confirmReplace = JOptionPane.showConfirmDialog(this,
                            "This will replace ALL existing tasks with the tasks from the file.\nAre you sure you want to continue?",
                            "Confirm Import (Replace All)",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);

                    if (confirmReplace == JOptionPane.YES_OPTION) {
                        // Delete all existing tasks
                        List<Task> currentTasks = taskService.getAllTasks(); // Get all to delete by ID
                        for (Task task : currentTasks) {
                            taskService.deleteTask(task.getId());
                        }
                        System.out.println("All existing tasks deleted.");

                        // Insert all imported tasks
                        int count = 0;
                        for (Task taskToImport : importedTasks) {
                            // IMPORTANT: The imported task already has an ID.
                            // We need a way to save it using that existing ID,
                            // or let the TaskService/Repository handle it (e.g., if ID doesn't exist, insert; else, update).
                            // Our current TaskService.save() should handle this if findById works.
                            // Also, the Task constructor used by Jackson needs to handle all fields.

                            // Let's assume TaskService.save() will insert if ID is new to this DB,
                            // or update if ID exists.
                            taskService.save(taskToImport); // This will use the ID from the JSON
                            count++;
                        }
                        JOptionPane.showMessageDialog(this,
                                count + " tasks imported successfully (replaced existing)!",
                                "Import Successful", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "No tasks found in the selected file or file is empty.", "Import Info", JOptionPane.INFORMATION_MESSAGE);
                }

            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                        "Error importing tasks: " + e.getMessage(),
                        "Import Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            } finally {
                loadTasks(); 
            }
        }
    }
    
    
    
    // -------------------------------------------------------------------------------------------------
    
    
    public void loadTasks() {
        TaskContainer.removeAll(); // Clear previous items
        System.out.println("loadTasks: Fetching tasks. Current Search: '" + currentSearchTerm +
                           "', Selected Nav: " + (selectedNavButton != null ? selectedNavButton.getText() : "Default/Today"));

        List<Task> tasksToDisplay; // This will be the final list for the UI
        LocalDate todayDate = LocalDate.now();

        // --- Step 1: Determine the base list of tasks from the service ---
        if (currentSearchTerm != null && !currentSearchTerm.isEmpty()) {
            System.out.println("loadTasks: Performing search for: '" + currentSearchTerm + "'");
            // Assuming searchActiveTasks filters out completed tasks by default.
            // If you want search to include completed for "All Projects", this needs adjustment
            // or a different search method from TaskService.
            tasksToDisplay = taskService.searchActiveTasks(currentSearchTerm);
            viewTitleLabel.setText("Search Results");
            titleDate.setText("For: '" + currentSearchTerm + "'");
            if (taskCountLabel != null) {
                taskCountLabel.setText(tasksToDisplay.size() + " result(s) found.");
            }

        } else if (selectedNavButton == today || selectedNavButton == null) { // Default to Today view
            viewTitleLabel.setText("Today's Tasks");
            tasksToDisplay = taskService.getActiveTasksByDate(todayDate); // Gets ONLY ACTIVE tasks for today
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy");
            titleDate.setText(todayDate.format(dateFormatter));
            if (taskCountLabel != null) {
                taskCountLabel.setText("You have " + tasksToDisplay.size() + " task(s) today.");
            }

        } else if (selectedNavButton == weekView) {
            viewTitleLabel.setText("This Week's Tasks");
            LocalDate startOfWeek = todayDate.with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY));
            LocalDate endOfWeek = todayDate.with(java.time.temporal.TemporalAdjusters.nextOrSame(java.time.DayOfWeek.SUNDAY));
            final LocalDate finalStart = startOfWeek;
            final LocalDate finalEnd = endOfWeek;
            tasksToDisplay = taskService.getActiveTasks().stream() 
                                .filter(task -> task.getDueDate() != null &&
                                                !task.getDueDate().isBefore(finalStart) &&
                                                !task.getDueDate().isAfter(finalEnd))
                                .collect(Collectors.toList()); 
            DateTimeFormatter weekDateFormatter = DateTimeFormatter.ofPattern("MMM d");
            titleDate.setText(startOfWeek.format(weekDateFormatter) + " - " + endOfWeek.format(weekDateFormatter));
            if (taskCountLabel != null) {
                 taskCountLabel.setText("You have " + tasksToDisplay.size() + " task(s) this week.");
            }

        } else if (selectedNavButton == allProjects) { 
            viewTitleLabel.setText("All Project Tasks");
            tasksToDisplay = taskService.getAllTasks(); 
            titleDate.setText("All Tasks (includes completed)");
            if (taskCountLabel != null) {
                taskCountLabel.setText(tasksToDisplay.size() + " total project task(s).");
            }

        } else if (selectedNavButton == academicTask) { 

            System.out.println("loadTasks: Academic/Stats view active, task list not populated.");

            if (TaskContainer.getComponentCount() > 0 && TaskContainer.getComponent(0) instanceof JLabel) {
                String text = ((JLabel) TaskContainer.getComponent(0)).getText();
                if (text != null && text.trim().startsWith("No tasks to display")) {
                    TaskContainer.removeAll(); 
                }
            }
            TaskContainer.revalidate();
            TaskContainer.repaint();
            return; 

        } else {
            viewTitleLabel.setText("All Active Tasks");
            tasksToDisplay = taskService.getActiveTasks(); 
            titleDate.setText("Overview");
            if (taskCountLabel != null) {
                taskCountLabel.setText(tasksToDisplay.size() + " active task(s).");
            }
        }

        // --- 2: Populate TaskContainer ---
        System.out.println("loadTasks: Displaying " + tasksToDisplay.size() + " tasks.");
        if (tasksToDisplay.isEmpty()) {
            String noTasksMessage = "   No tasks to display";
            if (currentSearchTerm != null && !currentSearchTerm.isEmpty()){
                noTasksMessage += " for your search.";
            } else {
                noTasksMessage += " for this view.";
            }
            TaskContainer.add(new javax.swing.JLabel(noTasksMessage));
        } else {
            for (Task task : tasksToDisplay) {
                taskItemPanel itemPanel = new taskItemPanel(this); // Pass 'this' (mainInterface)
                itemPanel.setTaskData(task);
                TaskContainer.add(itemPanel);
                TaskContainer.add(Box.createRigidArea(new Dimension(0, 8)));
            }
        }

        TaskContainer.revalidate();
        TaskContainer.repaint();
        System.out.println("loadTasks: Task loading and display complete.");
    }
     
    // public getter
    public TaskService getTaskService() {
        return this.taskService;
    }
    
    
    
    

    private void styleNavButton(javax.swing.JButton button) {
        if (button == null) return; // Safety check

        // FlatLaf Styling
        button.putClientProperty("JButton.buttonType", "borderless");
        button.setOpaque(false); 
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 15, 8, 15)); // Padding

        // Alignment
        button.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Sizing
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, button.getPreferredSize().height));

        // Adjustment for space between icon 
        button.setIconTextGap(12); 

        // --- Remove previous listeners to avoid duplicates ---
        for (ActionListener al : button.getActionListeners()) {
            button.removeActionListener(al);
        }

        button.addActionListener(e -> handleNavSelection(button));

        button.setForeground(defaultNavFgColor);
    }
    
    private void handleNavSelection(javax.swing.JButton clickedButton) {
        if (selectedNavButton != null) {
            selectedNavButton.setOpaque(false); 
            selectedNavButton.setContentAreaFilled(false);
            selectedNavButton.setForeground(defaultNavFgColor); 
        }
        
        selectedNavButton = clickedButton;
        
        if (selectedNavButton != null) {
            selectedNavButton.setOpaque(true); 
            selectedNavButton.setContentAreaFilled(true); 
            selectedNavButton.setBackground(selectedNavBgColor); 
            selectedNavButton.setForeground(selectedNavFgColor); 
            
            if (selectedNavButton.getParent() != null) {
                selectedNavButton.getParent().repaint();
            }
        }
        
        LayoutManager layout = MainContent.getLayout();
        if (layout instanceof BorderLayout) {
            BorderLayout borderLayout = (BorderLayout) layout;
            Component centerComponent = borderLayout.getLayoutComponent(BorderLayout.CENTER);
            if (centerComponent != null) {
                MainContent.remove(centerComponent);
            }
        } else {
            // Fallback if MainContent is not using BorderLayout (though it should be)
            MainContent.removeAll();
        }


        // 3. Add the appropriate panel based on the clicked button
        if (clickedButton == today || clickedButton == weekView || clickedButton == allProjects || clickedButton == null /* For default view */ ) {
            // If it's a task list view, add back the TaskArea
            // TaskArea is your JPanel that contains topBarArea (for date/filter) and jScrollPane1 (for tasks)
            MainContent.add(TaskArea, BorderLayout.CENTER);
            loadTasks(); // This populates TaskContainer inside TaskArea
            System.out.println( (clickedButton != null ? clickedButton.getText() : "Default") + " task list view selected.");

        } else if (clickedButton == academicTask) { // Assuming 'academicTask' is your JButton for statistics
            viewTitleLabel.setText("Productivity Statistics");
            titleDate.setText("Completion Overview"); // Or some relevant subtitle for the stats view
            if (taskCountLabel != null) taskCountLabel.setText(""); // Clear task count

            // Create and add the AcademicStatsPanel
            AcademicStatsPanel statsPanel = new AcademicStatsPanel(this.taskService); // Pass TaskService
            MainContent.add(statsPanel, BorderLayout.CENTER);
            System.out.println("Academic Tasks/Stats view selected and panel added.");

        } else if (clickedButton == importButton) {
            viewTitleLabel.setText("Settings");
            titleDate.setText("");
            if (taskCountLabel != null) taskCountLabel.setText("");
            MainContent.add(new JLabel("Settings View Placeholder - To be implemented"), BorderLayout.CENTER);
            System.out.println("Settings view selected.");
        }
        // Add more 'else if' blocks for other navigation items if they have unique views

        // 4. Revalidate and repaint MainContent to show the new panel
        MainContent.revalidate();
        MainContent.repaint();

        System.out.println("View updated in MainContent.");
     
        
    }
      
         
         
         
         
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MainContent = new javax.swing.JPanel();
        TopBar = new javax.swing.JPanel();
        viewTitleLabel = new javax.swing.JLabel();
        searchAddPanel = new javax.swing.JPanel();
        searchField = new javax.swing.JTextField();
        addTaskButton = new javax.swing.JButton();
        bulkActionPanel = new javax.swing.JPanel();
        selectedCountLabel = new javax.swing.JLabel();
        deselectAllButton = new javax.swing.JButton();
        selectAllButton = new javax.swing.JButton();
        deleteSelectedButton = new javax.swing.JButton();
        completeSelectedButton = new javax.swing.JButton();
        TaskArea = new javax.swing.JPanel();
        topBarArea = new javax.swing.JPanel();
        dateInfoPanel = new javax.swing.JPanel();
        titleDate = new javax.swing.JLabel();
        taskCountLabel = new javax.swing.JLabel();
        filterSortPanel = new javax.swing.JPanel();
        filterButton = new javax.swing.JButton();
        sortButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TaskContainer = new javax.swing.JPanel();
        SidePanel = new javax.swing.JPanel();
        titleAndSub = new javax.swing.JPanel();
        Title = new javax.swing.JLabel();
        Sub = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        NavSection = new javax.swing.JPanel();
        today = new javax.swing.JButton();
        weekView = new javax.swing.JButton();
        allProjects = new javax.swing.JButton();
        academicTask = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        importButton = new javax.swing.JButton();
        exportButton = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(200, 300), new java.awt.Dimension(0, 32767));
        jSeparator3 = new javax.swing.JSeparator();
        userProfilePanel = new javax.swing.JPanel();
        userIconLabel = new javax.swing.JLabel();
        userNameRolePanel = new javax.swing.JPanel();
        userNameLabel = new javax.swing.JLabel();
        userRoleLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(670, 590));

        MainContent.setLayout(new java.awt.BorderLayout());

        TopBar.setLayout(new java.awt.BorderLayout());

        viewTitleLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        viewTitleLabel.setText("Today's Task");
        TopBar.add(viewTitleLabel, java.awt.BorderLayout.WEST);

        searchAddPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        searchField.setColumns(15);
        searchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchFieldActionPerformed(evt);
            }
        });
        searchAddPanel.add(searchField);

        addTaskButton.setText("+ Add task");
        addTaskButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addTaskButtonActionPerformed(evt);
            }
        });
        searchAddPanel.add(addTaskButton);

        TopBar.add(searchAddPanel, java.awt.BorderLayout.EAST);

        MainContent.add(TopBar, java.awt.BorderLayout.NORTH);

        selectedCountLabel.setText("selectedCountLabel");
        bulkActionPanel.add(selectedCountLabel);

        deselectAllButton.setText("Deselect All");
        bulkActionPanel.add(deselectAllButton);

        selectAllButton.setText("Select All");
        bulkActionPanel.add(selectAllButton);

        deleteSelectedButton.setText("Delete");
        bulkActionPanel.add(deleteSelectedButton);

        completeSelectedButton.setText("Complete");
        bulkActionPanel.add(completeSelectedButton);

        MainContent.add(bulkActionPanel, java.awt.BorderLayout.SOUTH);

        TaskArea.setBackground(new java.awt.Color(204, 204, 204));
        TaskArea.setLayout(new java.awt.BorderLayout());

        topBarArea.setLayout(new java.awt.BorderLayout());

        dateInfoPanel.setLayout(new javax.swing.BoxLayout(dateInfoPanel, javax.swing.BoxLayout.Y_AXIS));

        titleDate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        titleDate.setText("Wednesday, May 1, 2024");
        dateInfoPanel.add(titleDate);

        taskCountLabel.setText("You have () task today.");
        dateInfoPanel.add(taskCountLabel);

        topBarArea.add(dateInfoPanel, java.awt.BorderLayout.WEST);

        filterSortPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        filterButton.setText("filter");
        filterSortPanel.add(filterButton);

        sortButton.setText("sort");
        filterSortPanel.add(sortButton);

        topBarArea.add(filterSortPanel, java.awt.BorderLayout.EAST);

        TaskArea.add(topBarArea, java.awt.BorderLayout.NORTH);

        jScrollPane1.setBorder(null);

        TaskContainer.setLayout(new javax.swing.BoxLayout(TaskContainer, javax.swing.BoxLayout.Y_AXIS));
        jScrollPane1.setViewportView(TaskContainer);

        TaskArea.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        MainContent.add(TaskArea, java.awt.BorderLayout.CENTER);

        getContentPane().add(MainContent, java.awt.BorderLayout.CENTER);

        SidePanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        SidePanel.setFocusCycleRoot(true);
        SidePanel.setPreferredSize(new java.awt.Dimension(200, 480));
        SidePanel.setLayout(new javax.swing.BoxLayout(SidePanel, javax.swing.BoxLayout.Y_AXIS));

        titleAndSub.setLayout(new javax.swing.BoxLayout(titleAndSub, javax.swing.BoxLayout.Y_AXIS));

        Title.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        Title.setForeground(new java.awt.Color(102, 51, 255));
        Title.setText("MyDay");
        titleAndSub.add(Title);

        Sub.setForeground(new java.awt.Color(153, 153, 153));
        Sub.setText("Task Manager");
        titleAndSub.add(Sub);

        SidePanel.add(titleAndSub);
        SidePanel.add(jSeparator1);

        NavSection.setLayout(new javax.swing.BoxLayout(NavSection, javax.swing.BoxLayout.Y_AXIS));

        today.setIcon(new javax.swing.ImageIcon(getClass().getResource("/graphics/todayicon.png"))); // NOI18N
        today.setText("Today");
        today.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        NavSection.add(today);

        weekView.setIcon(new javax.swing.ImageIcon(getClass().getResource("/graphics/monthicon.png"))); // NOI18N
        weekView.setText("Week View");
        weekView.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        NavSection.add(weekView);

        allProjects.setIcon(new javax.swing.ImageIcon(getClass().getResource("/graphics/projects.png"))); // NOI18N
        allProjects.setText("All Projects");
        allProjects.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        NavSection.add(allProjects);

        academicTask.setIcon(new javax.swing.ImageIcon(getClass().getResource("/graphics/task.png"))); // NOI18N
        academicTask.setText("Academic Task");
        academicTask.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        NavSection.add(academicTask);

        SidePanel.add(NavSection);
        SidePanel.add(jSeparator2);

        importButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/graphics/import.png"))); // NOI18N
        importButton.setText("Import Data");
        importButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importButtonActionPerformed(evt);
            }
        });
        SidePanel.add(importButton);

        exportButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/graphics/export.png"))); // NOI18N
        exportButton.setText("Export Data");
        SidePanel.add(exportButton);
        SidePanel.add(filler1);
        SidePanel.add(jSeparator3);

        userProfilePanel.setLayout(new javax.swing.BoxLayout(userProfilePanel, javax.swing.BoxLayout.LINE_AXIS));

        userIconLabel.setBackground(new java.awt.Color(0, 0, 0));
        userIconLabel.setText("icon");
        userProfilePanel.add(userIconLabel);

        userNameRolePanel.setLayout(new javax.swing.BoxLayout(userNameRolePanel, javax.swing.BoxLayout.Y_AXIS));

        userNameLabel.setBackground(new java.awt.Color(0, 0, 0));
        userNameLabel.setText("name");
        userNameRolePanel.add(userNameLabel);

        userRoleLabel.setBackground(new java.awt.Color(0, 0, 0));
        userRoleLabel.setText("role");
        userNameRolePanel.add(userRoleLabel);

        userProfilePanel.add(userNameRolePanel);

        SidePanel.add(userProfilePanel);

        getContentPane().add(SidePanel, java.awt.BorderLayout.WEST);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchFieldActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_searchFieldActionPerformed

    private void addTaskButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addTaskButtonActionPerformed
        // TODO add your handling code here:
        addTaskDialog dialog = new addTaskDialog(this, true, this.taskService);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
        System.out.println("mainInterface constructor: Calling loadTasks().");
        loadTasks();
    }//GEN-LAST:event_addTaskButtonActionPerformed

    private void importButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_importButtonActionPerformed

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel MainContent;
    private javax.swing.JPanel NavSection;
    private javax.swing.JPanel SidePanel;
    private javax.swing.JLabel Sub;
    private javax.swing.JPanel TaskArea;
    private javax.swing.JPanel TaskContainer;
    private javax.swing.JLabel Title;
    private javax.swing.JPanel TopBar;
    private javax.swing.JButton academicTask;
    private javax.swing.JButton addTaskButton;
    private javax.swing.JButton allProjects;
    private javax.swing.JPanel bulkActionPanel;
    private javax.swing.JButton completeSelectedButton;
    private javax.swing.JPanel dateInfoPanel;
    private javax.swing.JButton deleteSelectedButton;
    private javax.swing.JButton deselectAllButton;
    private javax.swing.JButton exportButton;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JButton filterButton;
    private javax.swing.JPanel filterSortPanel;
    private javax.swing.JButton importButton;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JPanel searchAddPanel;
    private javax.swing.JTextField searchField;
    private javax.swing.JButton selectAllButton;
    private javax.swing.JLabel selectedCountLabel;
    private javax.swing.JButton sortButton;
    private javax.swing.JLabel taskCountLabel;
    private javax.swing.JPanel titleAndSub;
    private javax.swing.JLabel titleDate;
    private javax.swing.JButton today;
    private javax.swing.JPanel topBarArea;
    private javax.swing.JLabel userIconLabel;
    private javax.swing.JLabel userNameLabel;
    private javax.swing.JPanel userNameRolePanel;
    private javax.swing.JPanel userProfilePanel;
    private javax.swing.JLabel userRoleLabel;
    private javax.swing.JLabel viewTitleLabel;
    private javax.swing.JButton weekView;
    // End of variables declaration//GEN-END:variables
}
