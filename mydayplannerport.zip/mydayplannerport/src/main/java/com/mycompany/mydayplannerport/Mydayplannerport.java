/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mydayplannerport;

/**
 *
 * @author Miguel Pogi
 */
public class Mydayplannerport {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
